export const environment = {
  production: true,
  apiUrl: 'https://mmcix.azure-api.net/qa-internal/20210729'
};
