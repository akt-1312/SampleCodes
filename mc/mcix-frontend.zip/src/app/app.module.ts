import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { TranslateModule, TranslateLoader, TranslateService, TranslateStore } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { ToastrModule } from 'ngx-toastr';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchModule } from './search/search.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
// import { FooterComponent } from './shared/component/footer/footer.component';
import { HeaderComponent } from './shared/component/header/header.component';
import { SidebarComponent } from './shared/component/sidebar/sidebar.component';
import { SearchbarComponent } from './shared/component/searchbar/searchbar.component';
import { TopbarComponent } from './shared/component/topbar/topbar.component';
import { HomeComponent } from './shared/component/home/home.component';
import { TestComponent } from './shared/component/test/test.component';
import { ReportModule } from './report/report.module';
import { UserModule } from './user/user.module';
import { UploadModule } from './upload/upload.module';
import { CompanyProfileModule } from './company-profile/company-profile.module';
import { AccountModule } from './account/account.module';
import { AuthInterceptor } from './shared/helper/auth.interceptor';
import { ShareModule } from './shared/module/share/share.module';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { ChartsModule } from 'ng2-charts';
import { ProfileComponent } from './shared/component/profile/profile.component';
import { ResetPasswordComponent } from './shared/component/reset-password/reset-password.component';
import { MfiModule } from './mfi/mfi.module';
import { DataTablesModule } from "angular-datatables";
import { NotificationDetailsComponent } from './shared/component/notification-details/notification-details.component';
import { GenerateKeysComponent } from './shared/component/generate-keys/generate-keys.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    // FooterComponent,
    HeaderComponent,
    SidebarComponent,
    SearchbarComponent,
    TopbarComponent,
    HomeComponent,
    TestComponent,
    ProfileComponent,
    ResetPasswordComponent,
    NotificationDetailsComponent,
    GenerateKeysComponent
  ],
  imports: [
    BrowserModule,    
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    SearchModule,
    DashboardModule,
    ReportModule,
    UserModule,
    UploadModule,
    CompanyProfileModule,
    AccountModule,
    ShareModule,
    ChartsModule, 
    DataTablesModule,
    MfiModule,   
    ToastrModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    TypeaheadModule.forRoot(), 
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    TranslateStore ,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
