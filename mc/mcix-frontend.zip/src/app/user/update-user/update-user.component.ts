import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { AccountService } from 'src/app/shared/service/account.service';
import { ClientService } from 'src/app/shared/service/client.service';
import { Observable, of, Subject } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';

import { IResRemainingSuperPowerCount } from 'src/app/shared/model/response/IResRemainingSuperPowerCount';
import { IReqSaveUserDetail } from 'src/app/shared/model/request/IReqSaveUserDetail';
import { IReqResetPasswordUser } from 'src/app/shared/model/request/IReqResetPasswordUser';
import { userRole } from 'src/app/shared/config/user-role';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.scss']
})
export class UpdateUserComponent implements OnInit {

  
  
  UserGUID = ''

  userResetForm: FormGroup = new FormGroup({
    Email: new FormControl(),
    Password: new FormControl(),
    ConfirmPassword: new FormControl()
  })

  userForm: FormGroup = new FormGroup({    
    pMFIAccountId: new FormControl(),
    pIsActive: new FormControl(),
    pRoleID: new FormControl(),
    pCheckDivisions: new FormControl(),
    pDivisionCode: new FormControl(),
    pTownshipCode: new FormControl()
  })

  loading = false;
  btnLoading = false;
  btnResetLoading =false;
  submitted = false;
  resetSubmitted = false;
  errorMsg = '';

  sysadminRole = userRole.sysAdmin;
  userRole = '';

  loadingRoles = false;
  roles$: Observable<[]>;

  loadingDivisions = false;
  divisions$: Observable<[]>;

  AccountGUID = '';

  userDetail = {}

  disableGetTownships = true;
  hideTownships = true;
  loadingTownships = false;
  townships$: Observable<[]>;

  countInfoShow = false;
  count: IResRemainingSuperPowerCount = { NumberofRemainingPowerUserCount: 0, NumberofRemainingSuperUserCount: 0 };

  loadingMfis = false;
  mfis$: Observable<[]>;

  arrActive = [
    { active: true, name: 'Yes' },
    { active: false, name: 'No' }
  ];

  pUserLocationJsonStr = ''

  passwordValidator = [Validators.required, Validators.minLength(8), Validators.maxLength(20), Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]
  

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private clientService: ClientService,
    private accountService: AccountService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.route.params.subscribe(params => {
      if (params.id) {        
        this.UserGUID = params.id        
      }
    })

    
    

    this.userResetForm = this.formBuilder.group({
      Email: ['', [Validators.required, Validators.email]],
      Password: ['', this.passwordValidator],
      ConfirmPassword: ['', this.passwordValidator]
    }, {
      validator: [
        this.ConfirmedValidator('Password', 'ConfirmPassword')]
    });

    this.userForm = this.formBuilder.group({      
      pMFIAccountId: [null],
      pIsActive: [null, [Validators.required]],
      pRoleID: [null, [Validators.required]],
      pCheckDivisions: [false],
      pDivisionCode:  [[]],
      pTownshipCode:  [[]],
    }, {
      validator: [ 
        this.DivisionTownshipValidator('pCheckDivisions', 'pDivisionCode', 'pTownshipCode')]
    });

    this.userRole = this.tokenStorageService.getUserRole();
    
    if (this.userRole === this.sysadminRole) {
      this.getMFIsWithNoAccounts()
    } else {
      this.AccountGUID = this.tokenStorageService.getAccountGUID()
      this.getRoles()
      this.getRemainingSuperPowerCount()
    }   
    
    
    this.getDivisionsByLender()

    this.getUserDetail()      
    this.disableGetTownships = true
  }

  get r() { return this.userResetForm.controls; } 
  get f() { return this.userForm.controls; } 

  // ConfirmedValidator(controlName: string, matchingControlName: string){
  //   return (formGroup: FormGroup) => {
  //       const control = formGroup.controls[controlName];
  //       const matchingControl = formGroup.controls[matchingControlName];
  //       if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
  //           return;
  //       }
  //       if (control.value !== matchingControl.value) {
  //           matchingControl.setErrors({ confirmedValidator: true });
  //       } else {
  //           matchingControl.setErrors(null);
  //       }
  //   }
  // }

  ConfirmedValidator(controlName: string, matchingControlName: string){
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        if (control.value || matchingControl.value) {
          control.setValidators(this.passwordValidator);
          matchingControl.setValidators(this.passwordValidator);
          if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
          }
        } else {            
          control.setValidators(null);
          control.setErrors(null);
          matchingControl.setValidators(null);
          matchingControl.setErrors(null);
        }
    }
  }

  DivisionTownshipValidator(pCheckDivisions: string, pDivisionCode: string, pTownshipCode: string) {
    return (formGroup: FormGroup) => {
      const cCheckDivisions = formGroup.controls[pCheckDivisions];
      const cDivisionCode = formGroup.controls[pDivisionCode];
      const cTownshipCode = formGroup.controls[pTownshipCode];
      
      if ( (cCheckDivisions.value) || (!cCheckDivisions.value && cDivisionCode.value.length > 0 && cTownshipCode.value.length > 0) ) {        
        cCheckDivisions.setErrors(null);
      } else {       
        cCheckDivisions.setErrors({ divisionTownshipValidator: true })
      }
    }
  }

  getMFIsWithNoAccounts(): void {
    this.loadingMfis = true;   
    this.mfis$ = this.clientService
                .getMFIsWithNoAccounts()
                .pipe(          
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingMfis=false)
                );    
  }

  getRoles(): void {
    this.loadingRoles = true;      
    this.roles$ = this.clientService
                .getRoles(
                  this.AccountGUID, 
                  this.tokenStorageService.getUserRole()
                )
                .pipe(           
                  // map(response => response.filter(item => item.ID !== 0)),         
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingRoles=false)
                );    
  }

  getUserDetail(): void {
    this.loading = true;
    this.clientService.getUserDetail(
        this.UserGUID
      ).subscribe(data => {
        console.log(data, 'getUserDetail')
        this.userDetail = data;

        const UserLocation = JSON.parse(data.UserLocation);        
        console.log(UserLocation, UserLocation.ptownshipRefId, UserLocation.pdivisionCode[0])

        this.userForm.patchValue({
          Email: data.Email,

          pIsActive: data.IsAccountActive === 'True' ? true : false,
          pRoleID: data.UserRoleId,
          pCheckDivisions: UserLocation.pdivisionCode[0] === 'All',
          pDivisionCode: UserLocation.pdivisionCode[0] !== 'All' ? UserLocation.pdivisionCode : [],
          pTownshipCode: UserLocation.pdivisionCode[0] !== 'All' ? UserLocation.ptownshipRefId.map(i=>Number(i)) : [],
        })
        
        if (UserLocation.pdivisionCode[0] !== 'All') {          
          this.hideTownships = false;
        } else {
          this.f.pDivisionCode.disable()
        }
        
        this.loading = false;
        this.getTownshipsByLender()

        
    },
    err=> {
      console.log(err,'getUserDetail')
      this.loading = false;
      this.toastr.error("Error.")
    })
  }

  getRemainingSuperPowerCount(): void {
    this.loading = true;
    this.clientService.getRemainingSuperPowerCount(
        this.AccountGUID
      ).subscribe(data => {
        console.log(data, 'getRemainingSuperPowerCount')
        this.count.NumberofRemainingPowerUserCount = data.NumberofRemainingPowerUserCount;
        this.count.NumberofRemainingSuperUserCount = data.NumberofRemainingSuperUserCount;
        this.countInfoShow = true;
        this.loading = false;
    },
    err=> {
      console.log(err,'getRemainingSuperPowerCount')
      this.loading = false;
      this.toastr.error("Error.")
    })
  }

  getDivisionsByLender(): void {
    this.loadingDivisions = true;      
    this.divisions$ = this.clientService
                .getDivisionsByLender(
                  this.tokenStorageService.getAccountGUID()
                )
                .pipe(                 
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingDivisions=false)
                );    
  }

  onCheckedDivisions(event): void {   

    if (event.target.checked) {
      this.userForm.patchValue({
        pDivisionCode: [],
        pTownshipCode: []
      })
      this.f.pDivisionCode.disable()
      this.disableGetTownships = true
      this.hideTownships = true;
    } else {
      this.f.pDivisionCode.enable()  
    }
  }

  onChangeDivisions(): void {        
    if (this.f.pDivisionCode.value.length > 0) {
      this.disableGetTownships = false;
    } else {
      this.disableGetTownships = true;
      this.hideTownships = true;
    }
  }

  onChangeTownships(): void {   
    console.log(this.f.pDivisionCode.value) 
    if (this.f.pDivisionCode.value.length > 0) {
      this.getTownshipsByLender()
      this.hideTownships = false;
    } else {
      this.hideTownships = true;
    }
  }

  
  getTownshipsByLender(): void {
    this.loadingTownships = true;      
    this.townships$ = this.clientService
                .getTownshipsByLender(
                  this.f.pDivisionCode.value.toString(),
                  this.tokenStorageService.getAccountGUID()
                )
                .pipe(           
                  map(response => response.map(item => {
                    return {...item, Name: `${item.Division} - ${item.Township}`}
                  })),       
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingTownships=false)
                );    
  }

  selectAll() {
    this.townships$.subscribe(item => {
      const arr = item.map(obj => obj['ID'])
      this.userForm.patchValue({
        pTownshipCode: arr
      })
    })
    
  }

  unselectAll() {
    this.userForm.patchValue({
      pTownshipCode: []
    })
  }

  onChangeMfi(): void {   
    // this.getAccountInfo();
    console.log(this.f.pMFIAccountId.value)
    this.AccountGUID = this.f.pMFIAccountId.value
    this.getRoles()
    this.getRemainingSuperPowerCount()
  }

  checkFormDisabled(): boolean {
    console.log(this.f.pCheckDivisions.value,' this.f.pCheckDivisions.value')
    if ((this.userForm.invalid) && (this.f.pCheckDivisions.value === false) ) {
      return true;
    }
    return false;
  }

  async onSubmit() {
    this.submitted = true;

    if (this.userForm.invalid) {
      return;
    }

    this.btnLoading = true;

    let pUserLocationJsonStr = '';
    if (this.f.pCheckDivisions.value) {
      const divisionsCode = await this.divisions$.toPromise().then(result => result.map(item => item['Code']))
      const divisionCodeObj = { pdivisionCode: divisionsCode }
      pUserLocationJsonStr = JSON.stringify(divisionCodeObj)
    } else {
      console.log(this.f.pTownshipCode.value)
      const townshipCodeObj = { ptownshipRefId: this.f.pTownshipCode.value.map(String) }
      pUserLocationJsonStr = JSON.stringify(townshipCodeObj)
    }

    
    
    const reqDetail: IReqSaveUserDetail = {
      pEmail: this.r.Email.value,
      pAppUserGUID: this.tokenStorageService.getUserGUID(),
      pAccountGUID: this.tokenStorageService.getAccountGUID(),
      pPhoneNumber: '',
      pRoleID: this.f.pRoleID.value,
      pIsActive: this.f.pIsActive.value,
      pUserLocationJsonStr: pUserLocationJsonStr
    }

    this.clientService.saveUserDetails(reqDetail).subscribe(data => {
      this.toastr.success(data)
      this.getRemainingSuperPowerCount()
      this.resetUserForm()
      this.btnLoading = false;
      
    },
    err => {
      console.log(err, 'error');
      this.toastr.error("Error.")
      this.btnLoading = false;
    })

    

  }

  resetUserForm(): void {
    this.userForm.patchValue({      
      pMFIAccountId: null,
      pIsActive: null,
      pRoleID: null,
      pCheckDivisions: false,
      pDivisionCode: [],
      pTownshipCode: []
    })
  }

  onResetSubmit(): void {
    this.resetSubmitted = true;

    if (this.userResetForm.invalid) {
      return;
    }

    this.btnResetLoading = true;

    const req: IReqResetPasswordUser = {
      UserId: this.UserGUID,
      Password: this.r.Password.value,
      ConfirmPassword: this.r.ConfirmPassword.value
    }

    this.accountService.resetPassword(req).subscribe(data => {
      this.toastr.success("Success")
      this.userResetForm.patchValue({
        Password: '',
        ConfirmPassword: ''
      })
      this.btnResetLoading = false;
    })
  }

}
