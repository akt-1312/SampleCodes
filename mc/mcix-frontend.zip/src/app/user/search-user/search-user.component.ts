import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as moment from 'moment';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';

import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ClientService } from 'src/app/shared/service/client.service';

import { IResAppUser } from 'src/app/shared/model/response/IResAppUser';
import { IReqInactivateActivateUser } from 'src/app/shared/model/request/IReqInactivateActivateUser';

@Component({
  selector: 'app-search-user',
  templateUrl: './search-user.component.html',
  styleUrls: ['./search-user.component.scss']
})
export class SearchUserComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  modalRef?: BsModalRef;

  

  users: IResAppUser[] = [];
  activeUsers: IResAppUser[] = [];
  user: IResAppUser;

  tblShow = false;
  loading = false;
  errorMsg = '';

  constructor(    
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService,
    private modalService: BsModalService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.dtOptions = {
      columns: [
        { "searchable": false, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false }
      ],
      order: [[ 6, 'asc' ]],
      responsive: true
      
    }; 

    this.getAppUsers();
  }
  
  getAppUsers(): void {
    this.loading = true;
    this.tblShow = false;
    this.clientService.getAppUsers(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        this.users = data;
        this.activeUsers = data;
        this.loading = false;
        
        setTimeout(() => {
          this.dtTrigger.next();
          this.tblShow = true;
        }, 500);
      },
      err => {
        this.errorMsg = err;
        this.loading = false;
      }
    )
  }

  onChange(event) {
    

    if (event.target.value !== 'All') {
      this.users = this.activeUsers.filter(user => user.IsActive === event.target.value)
    } else {
      this.users = this.activeUsers;
    }
    this.rerender();
  }

  openModal(template: TemplateRef<any>, user:IResAppUser) {
    this.user = user
    this.modalRef = this.modalService.show(template);
  }

  inactivateActivateUser() {

    const req: IReqInactivateActivateUser = {
      pUserGUID: this.user.UserGUID,
      pAppUserGUID: this.tokenStorageService.getUserGUID(),
      pIsActive: this.user.IsActive
    }

    this.clientService.inactivateActivateUser(req).subscribe(data => {
      this.toastr.success(data);
      this.modalRef?.hide();
      this.getAppUsers();
    })
    
  }

  changeDateFormat(date: string): string {
    return moment(new Date(date)).format("DD-MMM-YYYY")
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

}
