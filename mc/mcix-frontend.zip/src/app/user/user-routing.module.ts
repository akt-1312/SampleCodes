import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SearchUserComponent } from './search-user/search-user.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { AuthGuard } from '../auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/user/search', pathMatch: 'full' },
  { path: 'search', component:  SearchUserComponent, canActivate: [AuthGuard], data: {menuId: '38'} },
  { path: 'create', component:  CreateUserComponent, canActivate: [AuthGuard], data: {menuId: '39'} },
  { path: 'update/:id', component:  UpdateUserComponent, canActivate: [AuthGuard], data: {menuId: '39'} }     
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
