import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { forkJoin } from 'rxjs';
import { first } from 'rxjs/operators';

import { AuthService } from '../shared/service/auth.service';
import { ClientService } from '../shared/service/client.service';

interface PageStats {
  numberOfActiveMFIs?: number;
  numberOfActiveBorrowers?: number;
  numberOfActiveWriteOffs?: number;
  numberofTownships?: number;
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {  

  stats: PageStats = {};
  announcements = '';  

  loginForm: FormGroup = new FormGroup({
    username: new FormControl(),
    pssword: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;
  error = '';

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private clientService: ClientService
  ) {     
      if (this.authService.tokenValue.access_token) { 
        this.router.navigate(['/home']);
      }
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.email, Validators.required]],
      password: ['', [Validators.required]]
    });
    this.getAnnouncementsAndStats();

    
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }  

  getAnnouncementsAndStats(): void {
    this.loading = true;

    const pageAnnouncement = this.clientService.getLoginPageAnnouncements();
    const pageStats = this.clientService.getLoginPageStats();

    forkJoin([pageAnnouncement, pageStats]).subscribe(result => {
      this.announcements = result[0];
      this.stats = result[1];
      this.loading = false;
    }, error => {
      console.log(error, 'getAnnouncementsAndStats')
      this.loading = false;
    })
  }  

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    this.btnLoading = true;
    this.authService.login(this.f.username.value, this.f.password.value)
      .pipe(first())
      .subscribe({
          next: (next) => {
            // get return url from query parameters or default to home page
            // const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
            // console.log(returnUrl, 'returnUrl')
            // this.router.navigateByUrl(returnUrl);
          },
          error: error => {
            this.error = error.error.error_description;
            this.btnLoading = false;
          }
      });

    

  }

}
