
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { FileService } from 'src/app/shared/service/file.service';
import { ReportService } from 'src/app/shared/service/report.service';

@Component({
  selector: 'app-custom-report',
  templateUrl: './custom-report.component.html',
  styleUrls: ['./custom-report.component.scss']
})
export class CustomReportComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  modalRef?: BsModalRef;

  tblShow = false;
  loading = false;
  errorMsg = ''; 

  fileList: any = [];
  fileListArchived: any = [];
  fileListCustomReport: any = [];

  fileItem: any

  isArchived: boolean = false

  constructor(
    private toastr: ToastrService,
    private fileService: FileService,
    private modalService: BsModalService,
    private reportService: ReportService,
  ) { }

  ngOnInit(): void {    

    this.dtOptions = {
      columns: [
        { "searchable": true, "orderable": true },
        { "searchable": true, "orderable": true },
        { "searchable": true, "orderable": true },
        { "searchable": false, "orderable": false }
      ],
      order: [[ 0, 'desc' ]],
      responsive: true      
    };

    this.getFileList();
  } 

  getFileList(): void {  
    this.tblShow = false;
    this.loading = true;    
    this.fileService.list("spf", "Archive,CustomReport").subscribe(data => {

      const arr:any = []
      console.log(data,' data')

      data.forEach(item => {
        const split = item['FileName'].split('_')
        if (split.length === 3) {
          const dateWithFileExt = split[2];
          const dateWithoutFileExt = dateWithFileExt.substring(0, dateWithFileExt.lastIndexOf('.')) || dateWithFileExt;
          if (dateWithoutFileExt.length === 8) {   
            const date = `${dateWithoutFileExt.substring(6, 8)}/${dateWithoutFileExt.substring(4, 6)}/${dateWithoutFileExt.substring(0, 4)}`    
            arr.push({ ...item, date: date, timestamp: dateWithoutFileExt, archived: item.BlobPath === 'Archive' ? 'Yes': 'No' })
          }
        }
      });

      
      this.fileListCustomReport = arr.filter(item => item.BlobPath === 'CustomReport')
      this.fileListArchived = arr     ;
      this.fileList = this.fileListCustomReport; 
      this.loading = false;
      
      setTimeout(() => {
        this.dtTrigger.next();
        this.tblShow = true;
      }, 500);
    }, err => {
      this.errorMsg = err
      this.loading = false;
    }) 
  }

  checkArchived(event): void {
    this.isArchived = event.target.checked
    //  
    if (event.target.checked) {
      this.fileList = this.fileListArchived;
    } else {
      this.fileList = this.fileListCustomReport; 
    }
    this.rerender()   
  }

  downloadFile(item): void {
    // this.loading = true;   
    console.log(item, 'item')

    this.fileService.download(item.FileName, item.BlobContainerName, item.BlobPath).subscribe(data => {
      // this.loading = false;
    }, 
    err => {
      this.errorMsg = err
      // this.loading = false;
    })

  }

  openModal(template: TemplateRef<any>, item) {
    this.fileItem = item
    console.log(item)
    this.modalRef = this.modalService.show(template);
  }

  deleteFile(): void {
    console.log(this.fileItem)
    this.loading = true;   
    this.reportService.moveReportToDeleted(this.fileItem.FileName, this.fileItem.BlobContainerName, this.fileItem.BlobPath).subscribe(data => {
      this.loading = false;
      this.toastr.success(`Deleted the report '${this.fileItem.FileName}'!`)
      this.modalRef?.hide();
      this.getFileList();
    }, 
    err => {
      this.errorMsg = err
      this.loading = false;
      this.toastr.error('Error.')
      this.modalRef?.hide();
      
      this.getFileList();
    })
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();     
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }
}
