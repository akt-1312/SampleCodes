import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataTablesModule } from "angular-datatables";
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ShareModule } from '../shared/module/share/share.module';

import { ReportRoutingModule } from './report-routing.module';
import { CustomReportComponent } from './custom-report/custom-report.component';


@NgModule({
  declarations: [
    CustomReportComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    DataTablesModule,
    ShareModule,
    ReportRoutingModule,
    TooltipModule.forRoot()
  ]
})
export class ReportModule { }
