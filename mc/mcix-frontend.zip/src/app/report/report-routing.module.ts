import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { CustomReportComponent } from './custom-report/custom-report.component';

const routes: Routes = [
  { path: '', redirectTo: '/report/custom', pathMatch: 'full' },
  { path: 'custom', component:  CustomReportComponent, canActivate: [AuthGuard], data: {menuId: '53'} }     
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
