import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { UploadDataComponent } from './upload-data/upload-data.component';
import { UploadResultComponent } from './upload-result/upload-result.component';

const routes: Routes = [
  { path: '', redirectTo: '/upload/data', pathMatch: 'full' },
  { path: 'data', component:  UploadDataComponent, canActivate: [AuthGuard], data: {menuId: '40'} },
  { path: 'result', component:  UploadResultComponent }     
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UploadRoutingModule { }
