import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { Observable, of, Subject } from 'rxjs';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ToastrService } from 'ngx-toastr';
import { DataTableDirective } from 'angular-datatables';
import { catchError, finalize, map  } from 'rxjs/operators';

import { FileService } from 'src/app/shared/service/file.service';

@Component({
  selector: 'app-upload-data',
  templateUrl: './upload-data.component.html',
  styleUrls: ['./upload-data.component.scss']
})
export class UploadDataComponent implements OnDestroy, OnInit {

  filePlaceholder = "Choose a file..."
  selectedFiles?: FileList;
  currentFile?: File;
  progress = 0;
  message = '';

  

  isNoTesting = true;
  showInfo = false;
  showUploadBtn = false;
  pConfirmedBy = "";

 
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  
  fileStatusDescList: any = [];
  fileList: any = [];

  fileList$: Observable<[]>;

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private fileService: FileService,
    private tokenStorageService: TokenStorageService,
    ) {}

  ngOnInit(): void {

    this.dtOptions = {
      columns: [
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": false, orderable: false }
      ],
      order: [[ 1, 'desc' ]],
      responsive: true      
    }; 

    

    this.getUploadFileStatusDescriptionList();
    this.getFileList();
    
  }

  // ngAfterViewInit(): void {
  //   this.dtTrigger.next();
  // }

  // ngOnDestroy(): void {
  //   // Do not forget to unsubscribe the event
  //   this.dtTrigger.unsubscribe();
  // }

  // rerender(): void {
  //   this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
  //     // Destroy the table first
  //     dtInstance.destroy();
  //     // Call the dtTrigger to rerender again
  //     this.dtTrigger.next();
  //   });
  // }

  onCheckedTesting(event): void {
    console.log(event.target.checked, 'event')
    this.isNoTesting = !event.target.checked
  }

  selectFile(event: any): void {
    this.selectedFiles = event.target.files;
    console.log(this.selectedFiles)
    if (this.selectedFiles) {
      const file = this.selectedFiles.item(0);
      if (file) {
        this.filePlaceholder = file.name
        const fileNameWithoutExt = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;
        const validateFileName = this.checkFileNameValidate(fileNameWithoutExt);
        console.log(validateFileName)
        if (validateFileName) {
          this.showInfo = true;
        } else {
          this.showInfo = false;
          this.showUploadBtn = false;
          this.toastr.error("Invalid filename. File name must contain one of the template names. Please refer to the provided template list in the Templates section.")
        }
      }
    }
  }

  checkFileNameValidate(name): boolean {
    const fileNames = ['CERP Loans', 'Active Loans', 'Write Off', 'ThitsaID request form', 'Monthly active borrower count by township']
    return fileNames.some(element => element.toLowerCase() === name.toLowerCase())
  }

  checkedConfirmedBy(event): void {
    this.showUploadBtn = this.pConfirmedBy.length > 2 
  }

  getUploadFileStatusDescriptionList(): void {
    this.loading = true;    
    this.fileService.getUploadFileStatusDescriptionList().subscribe(data => {
      console.log(data, 'dd')
      this.fileStatusDescList = data
      this.loading = false;
    }, err => {
      this.errorMsg = err
      this.loading = false;
    }) 
  }

  

  getFileList(): void {  

    this.loading = true;    
    this.fileService.list("spf", "Inbox,Processed,Error").subscribe(data => {

      const arr:any = []
      data.forEach(item => {
        const split = item['FileName'].split('~')
        if (split.length === 4) {
          const status = split[3].split('.')[0];         

          const statusDesc = this.fileStatusDescList.filter(item => item.DisplayValues === status)[0].EnumDescription;
          
          arr.push({ folder: item['BlobPath'], filename: item['FileName'], container: item['BlobContainerName'], date: split[0], user: split[1], file: split[2], status: statusDesc })
        } else { 
          arr.push({ folder: item['BlobPath'], filename: item['FileName'], container: item['BlobContainerName'], date: split[0], user: split[1], file: split[2], status: '' })
        }
      })
      
      this.fileList = arr      
      this.loading = false;
      this.dtTrigger.next();
    }, err => {
      this.errorMsg = err
      this.loading = false;
    }) 
  }

  onConfirmAndUpload(): void {
    this.btnLoading = true;
    const userName = this.tokenStorageService.getUserName();
    console.log(userName, this.pConfirmedBy, encodeURIComponent(userName))
    const data = `userName=${encodeURIComponent(userName)}&pConfirmedBy=${this.pConfirmedBy}`
  

    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);
      if (file) {
        this.fileService.upload(data, file).subscribe(data => {
          this.btnLoading = false;
          this.toastr.success(data.ResponseMessage)
          this.getFileList()
        },
        err => {
          this.btnLoading = false;
          this.toastr.error("Error.")
        })
      }
    }
    
  }

  deleteFile(item) {
    this.loading = true;
    
    const filename = item.filename;
    const pShortURL = item.container
  
    this.fileService.delete(filename, pShortURL).subscribe(data => {
      this.loading = false;
      this.toastr.success(`${filename} deleted successfully.`)
      this.getFileList()
    },
    err => {
      this.loading = false;
      this.toastr.error("Error.")
    })

  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}

