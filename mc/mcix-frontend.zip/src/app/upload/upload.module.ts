import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from "angular-datatables";
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ShareModule } from '../shared/module/share/share.module';

import { UploadRoutingModule } from './upload-routing.module';
import { UploadDataComponent } from './upload-data/upload-data.component';
import { UploadResultComponent } from './upload-result/upload-result.component';


@NgModule({
  declarations: [
    UploadDataComponent,
    UploadResultComponent
  ],
  imports: [
    CommonModule,    
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    ShareModule,
    UploadRoutingModule,
    AccordionModule.forRoot(),
    TooltipModule.forRoot()
  ]
})
export class UploadModule { }
