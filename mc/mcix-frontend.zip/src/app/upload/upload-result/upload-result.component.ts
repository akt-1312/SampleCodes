import { Component, OnInit } from '@angular/core';
import { ActivatedRoute  } from "@angular/router";
import { FileService } from 'src/app/shared/service/file.service';

@Component({
  selector: 'app-upload-result',
  templateUrl: './upload-result.component.html',
  styleUrls: ['./upload-result.component.scss']
})
export class UploadResultComponent implements OnInit {

  result: any = []
  params: any = { subDirectory: '', fileName: '', containerName: '' }
  filename: ''
  loading = false;
  errorMsg = '';

  constructor(
    private route: ActivatedRoute, 
    private fileService: FileService
  ) { }

  ngOnInit(): void {
    this.getQueryParams()
    this.getFileResult();
  }

  getQueryParams() {
    this.route.queryParamMap
  .subscribe((params) => {

    this.params = { subDirectory: params.get('subDirectory'), fileName: params.get('fileName'), containerName: params.get('containerName') }

    this.filename = this.params['fileName'].split('~')[2]
    
    console.log(this.params)
  }
);
  }

  getFileResult(): void {
    this.loading = true;    
    this.fileService.getErrorInformation(this.params['subDirectory'], this.params['fileName'], this.params['containerName']).subscribe(data => {
      console.log(data, 'dd')
      this.result = data
      this.loading = false;
    }, err => {
      this.errorMsg = err
      this.loading = false;
    }) 
  }

}
