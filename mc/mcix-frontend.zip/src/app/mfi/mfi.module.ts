import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';
import { ShareModule } from '../shared/module/share/share.module';

import { MfiRoutingModule } from './mfi-routing.module';
import { ActiveSubscriptionComponent } from './active-subscription/active-subscription.component';
import { CreateMfiComponent } from './create-mfi/create-mfi.component';
import { EditMfiComponent } from './edit-mfi/edit-mfi.component';


@NgModule({
  declarations: [
    ActiveSubscriptionComponent,
    CreateMfiComponent,
    EditMfiComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ShareModule,
    NgSelectModule,
    MfiRoutingModule,
    BsDatepickerModule.forRoot()
  ]
})
export class MfiModule { }
