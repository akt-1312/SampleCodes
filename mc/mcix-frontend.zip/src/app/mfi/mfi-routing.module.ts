import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { ActiveSubscriptionComponent } from './active-subscription/active-subscription.component';
import { CreateMfiComponent } from './create-mfi/create-mfi.component';
import { EditMfiComponent } from './edit-mfi/edit-mfi.component';

const routes: Routes = [
  { path: '', redirectTo: '/mfi/active-subscription', pathMatch: 'full' },
  { path: 'active-subscription', component:  ActiveSubscriptionComponent, canActivate: [AuthGuard], data: {menuId: '45'} },
  { path: 'create', component:  CreateMfiComponent, canActivate: [AuthGuard], data: {menuId: '46'} },      
  { path: 'edit', component:  EditMfiComponent, canActivate: [AuthGuard], data: {menuId: '47'} }      
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MfiRoutingModule { }
