import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { Observable, of, Subject } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';
import { ClientService } from 'src/app/shared/service/client.service';
import { IReqUpdateMfi } from 'src/app/shared/model/request/IReqUpdateMfi';
import { IResAccountInfo } from 'src/app/shared/model/response/IResAccountInfo';

@Component({
  selector: 'app-edit-mfi',
  templateUrl: './edit-mfi.component.html',
  styleUrls: ['./edit-mfi.component.scss']
})
export class EditMfiComponent implements OnInit {

  mfiForm: FormGroup = new FormGroup({
    pMFIAccountId: new FormControl(),
    accountName: new FormControl(),
    lenderName: new FormControl(),
    shortUrl: new FormControl(),
    addressLine: new FormControl(), //Address Line
    contactTitle: new FormControl(), //Business Contact Title 
    itContactTitle: new FormControl(), //It Contract Title
    itContactName: new FormControl(), //It contract Name
    fullName: new FormControl(), //Business Contract Name
    contactEmail_1: new FormControl(), //Business Email
    contactEmail_2: new FormControl(), //It Email
    contactLandline_1: new FormControl(), //Business Contact Landline 11111
    contactLandline_2: new FormControl(), //IT Contact landline 33333
    contactMobile_1: new FormControl(), //Business Contract Mobile 22222
    contactMobile_2: new FormControl(), //It Contract Mobile 44444
    comments: new FormControl(),
    clientCount: new FormControl(),
    
  });

  loadingMfis = false;
  mfis$: Observable<[]>;

  accountInfo: IResAccountInfo;

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  constructor(
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.mfiForm = this.formBuilder.group({
      pMFIAccountId: [null, [Validators.required]],
      lenderName: ['', Validators.required],
      shortUrl: ['', Validators.required],
      addressLine: ['', Validators.required],
      contactTitle: ['', Validators.required],
      itContactTitle: ['', Validators.required],
      itContactName: ['', Validators.required],
      fullName: ['', Validators.required],
      contactEmail_1: ['', [Validators.required, Validators.email]],
      contactEmail_2: ['', [Validators.required, Validators.email]],
      contactLandline_1: ['', [Validators.pattern("^[0-9]*$")]],
      contactLandline_2: ['', [Validators.pattern("^[0-9]*$")]],
      contactMobile_1: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      contactMobile_2: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      comments: ['', Validators.required],
      clientCount: ['', [Validators.required, Validators.pattern("^[0-9]*$")]]
    });

    this.getAllMFI();

  }

  get f() { return this.mfiForm.controls; } 

  getAllMFI(): void {
    this.loadingMfis = true;      
    this.mfis$ = this.clientService
                .getAllMFIs(this.tokenStorageService.getUserGUID())
                .pipe(          
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingMfis=false)
                );
  }

  onChangeMfi(): void {   
    this.getAccountInfo();
  }

  getAccountInfo(): void {
    this.loading = true;
    this.clientService.getAccountInfo(this.f.pMFIAccountId.value).subscribe(
      data => {
        console.log('getAccountInfo', data);
        this.accountInfo = data;

        this.mfiForm.patchValue({ 
          lenderName: data.LenderName,
          shortUrl: data.ShortURL,
          contactTitle: data.ContactTitle,
          itContactTitle: data.ITContactTitle,
          itContactName: data.ITContactName,
          fullName: data.ContactFullName,
          addressLine: data.AddressLine1,
          contactEmail_1: data.ContactEmail1,
          contactEmail_2: data.ContactEmail2,
          contactLandline_1: data.ContactLandline1,
          contactLandline_2: data.ContactLandline2,
          contactMobile_1: data.ContactMobile1,
          contactMobile_2: data.ContactMobile2,
          comments: data.Comments,
          clientCount: data.ClientCountAtSignUp
        })

        this.loading = false;
      },
      err => {
        console.log('getAccountInfo', err);
        this.loading = false;
      }
    )
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.mfiForm.invalid) {
      return;
    }

    this.btnLoading = true;
    this.loading = true;

    const req: IReqUpdateMfi = {
      accountGUID: this.accountInfo.AccountGUID,
      accountName: this.accountInfo.AccountName,
      lenderName: this.f.lenderName.value,
      shortUrl: this.f.shortUrl.value,
      contactTitle: this.f.contactTitle.value,
      itContactTitle: this.f.itContactTitle.value,
      itContactName: this.f.itContactName.value,
      fullName: this.f.fullName.value,
      addressLine: this.f.addressLine.value,
      contactEmail_1: this.f.contactEmail_1.value,
      contactEmail_2: this.f.contactEmail_2.value,
      contactLandline_1: this.f.contactLandline_1.value,
      contactLandline_2: this.f.contactLandline_2.value,
      contactMobile_1: this.f.contactMobile_1.value,
      contactMobile_2: this.f.contactMobile_2.value,
      comments: this.f.comments.value,
      clientCount: this.f.clientCount.value,
      pAppUserGUID: this.tokenStorageService.getUserGUID(),
      isActive: this.accountInfo.isActive,
      accountRefNumber: this.accountInfo.AccountRefNumber
    }

    this.clientService.updateMFIInfo(req).subscribe(data => {
      console.log(data)
      this.toastr.success("Success.");
      this.loading = false;
      this.btnLoading = false;
    }, 
    err => {
      console.log('activateSubscription', err);
      this.loading = false;
      this.btnLoading = false;
      this.toastr.error("Error.");
    })
  }

  

}