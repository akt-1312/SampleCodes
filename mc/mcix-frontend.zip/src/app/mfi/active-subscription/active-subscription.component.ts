import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { Observable, of, Subject } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';

import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ClientService } from 'src/app/shared/service/client.service';
import { ToastrService } from 'ngx-toastr';

import { IReqActivateSubscription } from 'src/app/shared/model/request/IReqActivateSubscription';

@Component({
  selector: 'app-active-subscription',
  templateUrl: './active-subscription.component.html',
  styleUrls: ['./active-subscription.component.scss']
})
export class ActiveSubscriptionComponent implements OnInit {

  mfiForm: FormGroup = new FormGroup({
    pMFIAccountId: new FormControl(),
    pStartDate: new FormControl(),
    pEndDate: new FormControl()
  });

  loadingMfis = false;
  mfis$: Observable<[]>;

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  startDate = new Date()
  endDate = new Date()

  constructor(
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    let today = new Date();
    console.log(today.toISOString().split('T')[0])
    console.log(today.toISOString().split('T')[0]+ "T00:00:00.000Z")

    this.mfiForm = this.formBuilder.group({
      pMFIAccountId: [null, [Validators.required]],
      pStartDate: [null, [Validators.required]],
      pEndDate: [null, [Validators.required]]
    });

    this.getAllMFI();
  }  

  get f() { return this.mfiForm.controls; }  

  getAllMFI(): void {
    this.loadingMfis = true;      
    this.mfis$ = this.clientService
                .getAllMFIs(this.tokenStorageService.getUserGUID())
                .pipe(          
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingMfis=false)
                );
  }

  onChangeMfi(): void {
    console.log('change', this.f.pMFIAccountId.value)    
    this.getSubscriptions();
  }

  getSubscriptions(): void {
    this.loading = true;
    this.clientService.getSubscriptions(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        if (data.length > 0) {
          this.mfiForm.patchValue({ pStartDate: new Date(data[0].StartDate), pEndDate: new Date(data[0].EndDate) })
        }
        console.log('getSubscriptions', data[0]);
        this.loading = false;
      },
      err => {
        console.log('getSubscriptions', err);
        this.loading = false;
      }
    )
  }

  onSubmit(): void {   
    this.loading = true;
    const data: IReqActivateSubscription = {
      pAppUserGUID: this.tokenStorageService.getUserGUID(),
      pMFIAccountId: this.f.pMFIAccountId.value,
      pStartDate: this.f.pStartDate.value.toISOString().split('T')[0]+ "T00:00:00.000Z",
      pEndDate: this.f.pEndDate.value.toISOString().split('T')[0]+ "T00:00:00.000Z"
    }

    this.clientService.activateSubscription(data).subscribe(data => {
      console.log('activateSubscription', data);
      this.toastr.success("Success.");
      this.loading = false;
    },
    err => {
      console.log('activateSubscription', err);
      this.loading = false;
      this.toastr.error("Error.");
    })
  }

}
