import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ToastrService } from 'ngx-toastr';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ClientService } from 'src/app/shared/service/client.service';
import { IReqCreateMfi } from 'src/app/shared/model/request/IReqCreateMfi';

@Component({
  selector: 'app-create-mfi',
  templateUrl: './create-mfi.component.html',
  styleUrls: ['./create-mfi.component.scss']
})
export class CreateMfiComponent implements OnInit {

  mfiForm: FormGroup = new FormGroup({
    accountName: new FormControl(),
    lenderName: new FormControl(),
    shortUrl: new FormControl(),
    addressLine: new FormControl(), //Address Line
    contactTitle: new FormControl(), //Business Contact Title 
    itContactTitle: new FormControl(), //It Contract Title
    itContactName: new FormControl(), //It contract Name
    fullName: new FormControl(), //Business Contract Name
    contactEmail_1: new FormControl(), //Business Email
    contactEmail_2: new FormControl(), //It Email
    contactLandline_1: new FormControl(), //Business Contact Landline 11111
    contactLandline_2: new FormControl(), //IT Contact landline 33333
    contactMobile_1: new FormControl(), //Business Contract Mobile 22222
    contactMobile_2: new FormControl(), //It Contract Mobile 44444
    comments: new FormControl(),
    clientCount: new FormControl(),
    
  });

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  constructor(
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.mfiForm = this.formBuilder.group({
      accountName: ['', Validators.required],
      lenderName: ['', Validators.required],
      shortUrl: ['', Validators.required],
      addressLine: ['', Validators.required],
      contactTitle: ['', Validators.required],
      itContactTitle: ['', Validators.required],
      itContactName: ['', Validators.required],
      fullName: ['', Validators.required],
      contactEmail_1: ['', [Validators.required, Validators.email]],
      contactEmail_2: ['', [Validators.required, Validators.email]],
      contactLandline_1: ['', [Validators.pattern("^[0-9]*$")]],
      contactLandline_2: ['', [Validators.pattern("^[0-9]*$")]],
      contactMobile_1: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      contactMobile_2: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      comments: ['', Validators.required],
      clientCount: ['', [Validators.required, Validators.pattern("^[0-9]*$")]]
    });

  }

  get f() { return this.mfiForm.controls; } 

  onSubmit(): void {
    this.submitted = true;

    if (this.mfiForm.invalid) {
      return;
    }

    this.btnLoading = true;
    this.loading = true;

    const req: IReqCreateMfi = {
      accountGUID: '',
      accountName: this.f.accountName.value,
      lenderName: this.f.lenderName.value,
      shortUrl: this.f.shortUrl.value,
      contactTitle: this.f.contactTitle.value,
      itContactTitle: this.f.itContactTitle.value,
      itContactName: this.f.itContactName.value,
      fullName: this.f.fullName.value,
      addressLine: this.f.addressLine.value,
      contactEmail_1: this.f.contactEmail_1.value,
      contactEmail_2: this.f.contactEmail_2.value,
      contactLandline_1: this.f.contactLandline_1.value,
      contactLandline_2: this.f.contactLandline_2.value,
      contactMobile_1: this.f.contactMobile_1.value,
      contactMobile_2: this.f.contactMobile_2.value,
      comments: this.f.comments.value,
      clientCount: this.f.clientCount.value,
      pAppUserGUID: this.tokenStorageService.getUserGUID(),
    }

    this.clientService.registerNewMFI(req).subscribe(data => {
      this.toastr.success("Success.");
      this.loading = false;
      this.btnLoading = false;
    }, 
    err => {
      console.log('activateSubscription', err);
      this.loading = false;
      this.btnLoading = false;
      this.toastr.error("Error.");
    })
  }

  

}
