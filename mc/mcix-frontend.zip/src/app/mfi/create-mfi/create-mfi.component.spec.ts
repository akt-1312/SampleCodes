import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateMfiComponent } from './create-mfi.component';

describe('CreateMfiComponent', () => {
  let component: CreateMfiComponent;
  let fixture: ComponentFixture<CreateMfiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateMfiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateMfiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
