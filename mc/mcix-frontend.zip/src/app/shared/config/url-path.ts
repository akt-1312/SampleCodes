

export const urlPath = {
    'token': 'Token',
    'app': {
        'getDivisions': 'api/App/GetDivisions',
        'getTownships': 'api/App/GetTownships',
        'getReportingDateForCompanyProfile': 'api/App/GetReportingDateForCompanyProfile',
    },
    'dashboard': {
        'getOverlapBorrowers': 'api/Dashboard/GetOverlapBorrowers',
        'getOverlapLoanCount': 'api/Dashboard/GetOverlapLoanCount',
        'getInquiryByAccount': 'api/Dashboard/GetInquiryByAccount',
        'getSearchRecordByUser': 'api/Dashboard/GetSearchRecordByUser',
        'getPenetrationRate': 'api/Dashboard/GetPenetrationRate',
        'getOverlapBorrowersTrend': 'api/Dashboard/GetOverlapBorrowersTrend',
        'getActiveClientMonthlyUpload': 'api/Dashboard/GetActiveClientMonthlyUpload',
        'getWriteOffClientMonthlyUpload': 'api/Dashboard/GetWriteOffClientMonthlyUpload',
        'getPublicationListBlobs': 'api/Dashboard/GetPublicationListBlobs',
        'getCreditReport': 'api/Dashboard/GetCreditReport',
        'getRptUserTrend': 'api/Dashboard/GetRptUserTrend',
        'getBase64BlobPdfData': 'api/Dashboard/GetBase64BlobPdfData'
    },
    'client': {
        'getCurrentUser': 'api/Client/GetCurrentUser',
        'getUserDetail': 'api/Client/GetUserDetail',
        'getAccountInfo': 'api/Client/GetAccountInfo',
        'getComplianceInfo': 'api/Client/GetComplianceInfo',
        'getSubscriptions': 'api/Client/GetSubscriptions',
        'getAppUsers': 'api/Client/GetAppUsers',
        'getRoles': 'api/Client/GetRoles',
        'getRemainingSuperPowerCount': 'api/Client/GetRemainingSuperPowerCount',
        'getDivisionsByLender': 'api/Client/GetDivisionsByLender',
        'getTownshipsByLender': 'api/Client/GetTownshipsByLender',
        'getSearchAuditResultsForAllUsers': 'api/Client/GetSearchAuditResultsForAllUsers',
        'getSearchAuditResults': 'api/Client/GetSearchAuditResults',

        'getNotificationSummary': 'api/Client/GetNotificationSummary',
        'getNotificationDetails': 'api/Client/GetNotificationDetails',
        'getLoginPageStats': 'api/Client/GetLoginPageStats',
        'getLoginPageAnnouncements': 'api/Client/GetLoginPageAnnouncements',
        'getFieldAccessLevel': 'api/Client/GetFieldAccessLevel',
        'getAllMFIs': 'api/Client/GetAllMFIs',
        'registerNewMFI': 'api/Client/RegisterNewMFI',
        'updateMFIInfo': 'api/Client/UpdateMFIInfo',
        'activateSubscription': 'api/Client/ActivateSubscription',
        'saveUserDetails': 'api/Client/SaveUserDetails',
        'getMFIsWithNoAccounts': 'api/Client/GetMFIsWithNoAccounts',
        'inactivateActivateUser': 'api/Client/InactivateActivateUser',
        'getLandingPageInfo': 'api/Client/GetLandingPageInfo',
        'getAppKeys': 'api/Client/GetAppKeys'
        
    },
    'search': {
        'getNRCDivisionTownshipValues': 'api/search/GetNRCDivisionTownshipValues',
        'simpleSearch': 'api/search/SimpleSearch',
        'bulkSearch': 'api/search/BulkSearch'
    },
    'company_profile': {
        'getCompanyProfile': 'api/CompanyProfile/GetCompanyProfile',
        'getCompanyProfileDetails': 'api/CompanyProfile/GetCompanyProfileDetails'
    },
    'account': {
        'changePassword': 'api/Account/ChangePassword',
        'register': 'api/Account/Register',
        'resetPassword': 'api/Account/ResetPassword'
    },
    'file': {
        'getUploadFileStatusDescriptionList': 'api/File/GetUploadFileStatusDescriptionList',
        'list': 'api/File/List',
        'getErrorInformation': 'api/File/GetErrorInformation',
        'upload': 'api/File/Upload',
        'delete': 'api/File/Delete',
        'download': 'api/File/Download'
    },
    'report': {
        'moveReportToDeleted': 'api/Report/MoveReportToDeleted'
    },
}