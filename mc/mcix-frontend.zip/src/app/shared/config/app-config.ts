export const appConfig = {
    
}