export const menuIds = {
    'search': {
        'parent_parent_search': '1',
        'parent_search': '8',
        'child_search_simple': '23',
        'child_search_bulk': '24'
    },
    'dashboard': {
        'dashboard': '2',
        'parent_parent_overlap': '2',
        'parent_overlap': '9',
        'child_overlap_summary': '25',
        'child_overlap_detail': '26',
        'child_overlap_trend': '27',
        'parent_parent_upload_stats': '2',
        'parent_upload_stats': '10',
        'child_upload_active': '28',
        'child_upload_write_off': '29',
        'child_upload_problematic': '30',
        'parent_parent_search_stats': '2',
        'parent_search_stats': '11',
        'child_search_per_user': '31',
        'child_search_per_month': '32',
        'parent_parent_penetration_rate': '2',
        'parent_penetration_rate': '12',
        'child_adjusted_penetration_rate': '33',        
        'parent_parent_publication': '2',
        'parent_publication': '15',
        'child_publication': '37',
        'parent_parent_audit': '2',
        'parent_audit': '13',
        'child_audit_overview': '34',
        'child_audit_detail': '35'
    },
    'report': {
        'parent_parent_report': '51',
        'parent_report': '52',
        'child_custom_report': '53'
    },
    'users': {
        'parent_parent_users': '3',
        'parent_users': '16',
        'child_search_users': '38',
        'child_new_user': '39'
    },
    'mfi': {
        'parent_parent_mfi': '7',
        'parent_mfi': '22',
        'child_active_subscription': '45',
        'child_create_mfi': '46',
        'child_edit_mfi': '47'
    },
    'upload_data': {
        'parent_parent_upload_data': '4',
        'parent_upload_data': '18',
        'child_upload_data': '40'
    },
    'company_profile': {
        'parent_parent_company_profile': '5',
        'parent_company_profile': '19',
        'child_company_profile_stats': '41'
    },
    'account': {
        'parent_parent_account': '6',
        'parent_account': '20',
        'child_account_info': '42',
        'child_account_permission': '43'
    },
    'credit_report': {
        'print': '50'
    }
}