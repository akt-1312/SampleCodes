

export const userRole = {
    'user': 'user',
    'powerUser': 'poweruser',
    'superUser': 'superuser',
    'dashboardAdmin': 'dashboardadmin',
    'dashboardSuperuser': 'dashboardsuperuser',
    'sysAdmin': 'sysadmin'
}