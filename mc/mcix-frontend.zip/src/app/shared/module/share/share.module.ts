import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { ShareRoutingModule } from './share-routing.module';
import { LoadingComponent } from '../../component/loading/loading.component';
import { FooterComponent } from '../../component/footer/footer.component';
import { LanguageSwitchComponent } from '../../component/language-switch/language-switch.component';


@NgModule({
  declarations: [
    LoadingComponent,
    FooterComponent,
    LanguageSwitchComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ShareRoutingModule
  ],
  exports: [
    LoadingComponent,
    FooterComponent,
    LanguageSwitchComponent,
    TranslateModule
  ]
})
export class ShareModule { }
