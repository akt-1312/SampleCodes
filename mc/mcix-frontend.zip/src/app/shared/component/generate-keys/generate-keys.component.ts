import { Component, OnInit } from '@angular/core';
import { ClientService } from '../../service/client.service';

@Component({
  selector: 'app-generate-keys',
  templateUrl: './generate-keys.component.html',
  styleUrls: ['./generate-keys.component.scss']
})
export class GenerateKeysComponent implements OnInit {

  loading = false;
  errorMsg = '';

  keys: any[] = []

  constructor(
    private clientService: ClientService,
  ) { }

  ngOnInit(): void {
    this.getAppKeys()
  }

  getAppKeys(): void {
    this.loading = true;
    this.clientService.getAppKeys().subscribe(data => {
      this.keys = data;
      this.loading = false;
    },
    err => {
      this.errorMsg = err;
      this.loading = false;
    })
  }

}
