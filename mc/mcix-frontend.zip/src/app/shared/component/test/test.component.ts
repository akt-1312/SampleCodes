import { Component, OnInit } from '@angular/core';
import { 
  AbstractControl,
  FormBuilder, 
  FormGroup, 
  FormControl,
  Validators 
} from "@angular/forms";
import { Router } from "@angular/router";
// import { TokenService } from '../../services/token/token.service';
// import { TokenStorageService } from '../../services/token/token-storage.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {

  loginForm: FormGroup = new FormGroup({
    username: new FormControl(),
    pssword: new FormControl()
  });
  submitted = false;

  constructor(
    private fb: FormBuilder, 
    // private tokenService: TokenService, 
    // private tokenStorage: TokenStorageService,
    private router: Router
  ) { }

  

  ngOnInit(): void { 
    this.loginForm = this.fb.group({
      username: ['', [Validators.email, Validators.required]],
      password: ['', [Validators.required]]
    });

    // if (this.tokenStorage.getToken()) {
    //   console.log(this.tokenStorage.getToken(), ' yes token is ok')
    // }
  }  

  get f(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  onSubmit(): void {
    console.log('login form');
    // this.submitted = true;
    // if (this.loginForm.valid) {
    //   console.log('valid', this.loginForm.value);

    //   const { username, password } = this.loginForm.value;

    //   console.log('yes ok', username, password);

    //   this.tokenService
    //     .login(username, password)
    //     .subscribe(
    //       data => {
    //         console.log('data is ', data);
    //         this.tokenStorage.saveToken(data.access_token);
    //         this.tokenStorage.saveUser(data.userName);
    //         this.loginForm.reset();
    //       },
    //       err => {
    //         console.log(err);
    //         alert(err.message);
    //       }
    //     );

      
    // }
  }

  onGetLoginPageAnnouncements(): void {
    // this.tokenService.testGetLoginPageAnnouncements().subscribe(
    //   data => {
    //     console.log(data);
    //     alert(data);
    //   },
    //   err => {
    //     console.log(err);
    //     alert(err.message);
    //   }
    // )
  }

  onGetLoginPageStats(): void {
    // this.tokenService.testGetLoginPageStats().subscribe(
    //   data => {
    //     console.log(data);
    //     alert(JSON.stringify(data));
    //   },
    //   err => {
    //     console.log(err);
    //     alert(err.message);
    //   }
    // )
  }

}
