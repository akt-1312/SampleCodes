import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SearchService } from '../../service/search.service';
import { IResTownship } from '../../model/response/IResTownship';

@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.scss']
})
export class SearchbarComponent implements OnInit {

  @Input() styleClass: string; 

  loading = false;
  errorMsg = '';

  townships: IResTownship[] = []
  township = '';

  constructor(
    private router: Router,
    private searchService: SearchService,
  ) { }

  ngOnInit(): void {
    this.getNRCDivisionTownshipValues();
  }

  getNRCDivisionTownshipValues(): void {
    this.loading = true;
    this.searchService.getNRCDivisionTownshipValues().subscribe(data => {
      this.townships = data.filter(item => item.ID !== 0)
      this.loading = false;
    },
    err => {
      this.errorMsg = err;
      this.loading = false;
    })
  }

  goToSimpleSearch(event): void {   
    this.router.navigate(['/search/simple'], { queryParams: { t: this.township } });
    this.township = '';
  }

}
