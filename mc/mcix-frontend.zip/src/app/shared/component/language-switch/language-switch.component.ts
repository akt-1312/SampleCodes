import { Component, OnInit, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TokenStorageService } from '../../service/token-storage.service';

@Component({
  selector: 'language-switch',
  templateUrl: './language-switch.component.html',
  styleUrls: ['./language-switch.component.scss']
})
export class LanguageSwitchComponent implements OnInit {

  @Input() styleClass: string; 

  langChecked = false

  constructor(
    private translate: TranslateService,
    private tokenStorageService: TokenStorageService,
  ) { }

  ngOnInit(): void {

    const lang = this.tokenStorageService.getLang();
    this.langChecked = lang === 'my'
  }

  switchLanguage(event: any): void {
    const lang = event.target.checked ? 'my' : 'en';
    this.translate.use(lang);
    this.tokenStorageService.saveLang(lang);
  }

}
