import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { TokenStorageService } from '../../service/token-storage.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  profileForm: FormGroup = new FormGroup({
    username: new FormControl(),
    password: new FormControl()
  });

  
  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private tokenStorageService: TokenStorageService,
  ) { }

  ngOnInit(): void {

    this.profileForm.patchValue({
      username: this.tokenStorageService.getUserName()
    })

  }

  get f() { return this.profileForm.controls; }

  onSubmit() {

  }

}
