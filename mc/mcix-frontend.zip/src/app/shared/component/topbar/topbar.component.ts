import { Component, OnInit, TemplateRef  } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { AuthService } from '../../service/auth.service';
import { TokenStorageService } from '../../service/token-storage.service';
import { ClientService } from '../../service/client.service';

@Component({
  selector: 'app-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss']
})
export class TopbarComponent implements OnInit {

  modalRef?: BsModalRef;
  noti: any = []

  constructor(
    private authService: AuthService,
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.getNotificationSummary()
  }

  getNotificationSummary(): void {
    this.clientService.getNotificationSummary(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        this.noti = data
      },
      err => {
        console.log('getNotificationSummary', err);
      }
    )
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  logout() {
    this.authService.logout();
    this.modalRef?.hide();
  }

}
