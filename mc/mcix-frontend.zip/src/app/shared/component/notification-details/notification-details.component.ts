import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { ClientService } from '../../service/client.service';

import { IResNotiDetails } from '../../model/response/IResNotiDetailsts';

@Component({
  selector: 'app-notification-details',
  templateUrl: './notification-details.component.html',
  styleUrls: ['./notification-details.component.scss']
})
export class NotificationDetailsComponent implements OnInit {

  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  details: IResNotiDetails[]
  typeIcon = ''

  loading = false;
  errorMsg = ''; 

  constructor(
    private route: ActivatedRoute,
    private clientService: ClientService
  ) { }

  ngOnInit(): void {

    this.dtOptions = {
      responsive: true
    }

    this.route.params.subscribe(params => {
      if (params.type) {
        if (params.type === 'Overlap') {
          this.typeIcon = '<i class="fas fa-star text-primary"></i>'
        } else if (params.type === 'Risk') {
          this.typeIcon = '<i class="fas fa-exclamation-triangle text-danger"></i>'
        } else {
          this.typeIcon = '<i class="fas fa-times-circle text-warning "></i>'
        }
        this.getNotificationDetails(params.type)        
      }
    }) 
  }

  getNotificationDetails(pNotificationType: string): void {
    this.loading = true;
    this.clientService.getNotificationDetails(pNotificationType).subscribe(data => {
      this.loading = false;
      this.details = data;
      this.dtTrigger.next();
    },
  err => {
    this.errorMsg = err;
    this.loading = false;
  })
  }

  

}
