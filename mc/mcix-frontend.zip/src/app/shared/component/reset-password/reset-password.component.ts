import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { Observable, of, Subject } from 'rxjs';
import { AccountService } from '../../service/account.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  resetForm: FormGroup = new FormGroup({
    OldPassword: new FormControl(),
    NewPassword: new FormControl(),
    ConfirmPassword: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;

  isSuccess = false;
  infoMsg = '';


  constructor(
    private formBuilder: FormBuilder,
    private accountService: AccountService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.resetForm = this.formBuilder.group({
      OldPassword: ['', [
        Validators.required, 
        Validators.minLength(8), 
        Validators.maxLength(20), 
        Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]
      ],
      NewPassword: ['', [
        Validators.required, 
        Validators.minLength(8), 
        Validators.maxLength(20), 
        Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]
      ],
      ConfirmPassword: ['', [
        Validators.required, 
        Validators.minLength(8), 
        Validators.maxLength(20), 
        Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]
      ]
    }, {
      validator: this.ConfirmedValidator('NewPassword', 'ConfirmPassword')
    });

    this.loadingSign()

  }

  get f() { return this.resetForm.controls; }
  
  ConfirmedValidator(controlName: string, matchingControlName: string){
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
            return;
        }
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}

loadingSign() {
  this.loading = true;
  setTimeout(() => {
    this.loading = false
  }, 2000)
}

  onSubmit(): void {
    this.submitted = true;

    if (this.resetForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.accountService.changePassword(
      this.f.OldPassword.value,
      this.f.NewPassword.value,
      this.f.ConfirmPassword.value
    ).subscribe(data => {     
      this.isSuccess = true;
      this.infoMsg = 'Password reset successfully.';
      this.btnLoading = false;
    },
    err => {
      this.isSuccess = false;
      this.infoMsg = err.ModelState.Error[0]
      this.btnLoading = false;
    })
  }

}
