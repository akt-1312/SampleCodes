import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ClientService } from '../../service/client.service';

import { History, IResLandingPageInfo, Main, Other } from '../../model/response/IResLandingPageInfo';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  loading = false;
  errorMsg = ''; 

  data: IResLandingPageInfo;
  main: Main;
  other: Other[];
  history: History[];


  constructor(
    private clientService: ClientService
  ) { }

  ngOnInit(): void {
    this.getLandingPageInfo();    
  }

  getLandingPageInfo(): void {
    this.loading = true;
    this.clientService.getLandingPageInfo().subscribe(data => {
      this.data = data;
      this.main = this.data.Data.Main[0];
      this.other = this.data.Data.Others;
      this.history = this.data.Data.History;

      console.log(this.main, this.other, this.history)
      this.loading = false;
    },
    err => {
      this.loading = false;
      this.errorMsg = err;
    })
  }

  changeDateFormat(date: string): string {
    return moment(new Date(date)).format("DD/MM/YYYY")
  }

  changeDateMonthFormat(date: string): string {
    return moment(new Date(date)).format("MMM")
  }

  changeDateDayFormat(date: string): string {
    return moment(new Date(date)).format("DD")
  }

}
