import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

import { IReqAccountInfo } from '../model/request/IReqAccountInfo';
import { IReqCreateMfi } from '../model/request/IReqCreateMfi';
import { IReqActivateSubscription } from '../model/request/IReqActivateSubscription';
import { IReqSaveUserDetail } from '../model/request/IReqSaveUserDetail';
import { IReqInactivateActivateUser } from '../model/request/IReqInactivateActivateUser';

@Injectable({ providedIn: 'root' })
export class ClientService {

    constructor(
        private http: HttpClient
    ) {}

    getLoginPageAnnouncements(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getLoginPageAnnouncements}`);
    }

    getLoginPageStats(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getLoginPageStats}`);
    }

    getLandingPageInfo(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getLandingPageInfo}`);
    }

    getCurrentUser(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getCurrentUser}`);
    }

    getNotificationSummary(accountGUID: string): Observable<any> {
        const params = new HttpParams().set('accountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getNotificationSummary}`, {params});
    }

    getNotificationDetails(pNotificationType: string): Observable<any> {
        const params = new HttpParams().set('pNotificationType', pNotificationType);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getNotificationDetails}`, {params});
    }

    getAppUsers(accountGUID: string): Observable<any> {
        const params = new HttpParams().set('pAccountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getAppUsers}`, {params});
    }

    getRoles(accountGUID: string, pRoleName: string): Observable<any> {
        const params = new HttpParams().set('pAccountGUID', accountGUID).set('pRoleName', pRoleName);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getRoles}`, {params});
    }

    getRemainingSuperPowerCount(accountGUID: string): Observable<any> {
        const params = new HttpParams().set('pAccountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getRemainingSuperPowerCount}`, {params});
    }

    getTownshipsByLender(divisionCode: string, accountGUID: string): Observable<any> {
        const params = new HttpParams().set('divisionCode', divisionCode).set('accountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getTownshipsByLender}`, {params});
    }

    getDivisionsByLender(accountGUID: string): Observable<any> {
        const params = new HttpParams().set('accountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getDivisionsByLender}`, {params});
    }

    getUserDetail(userGUID: string): Observable<any> {
        const params = new HttpParams().set('pUserGUID', userGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getUserDetail}`, {params});
    }

    getAppKeys(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getAppKeys}`);
    }

    getSearchAuditResultsForAllUsers(accountGUID: string, startDateStr: string, endDateStr: string, offHours: string): Observable<any> {
        const params = new HttpParams()
            .set('accountGUID', accountGUID)
            .set('startDateStr', startDateStr)
            .set('endDateStr', endDateStr)
            .set('offHours', offHours);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getSearchAuditResultsForAllUsers}`, {params});
    }

    getSearchAuditResults(userGUID: string, startDateStr: string, endDateStr: string, offHours: string): Observable<any> {
        const params = new HttpParams()
            .set('userGUID', userGUID)
            .set('startDateStr', startDateStr)
            .set('endDateStr', endDateStr)
            .set('offHours', offHours);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getSearchAuditResults}`, {params});
    }

    getSubscriptions(accountGUID: string): Observable<any> {
        const params = new HttpParams()
            .set('pAccountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getSubscriptions}`, {params});
    }

    getAccountInfo(accountGUID: string): Observable<any> {
        const params = new HttpParams()
            .set('pAccountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getAccountInfo}`, {params});
    }

    getMFIsWithNoAccounts(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getMFIsWithNoAccounts}`);
    }

    getComplianceInfo(accountGUID: string): Observable<any> {
        const params = new HttpParams()
            .set('pAccountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getComplianceInfo}`, {params});
    }

    getFieldAccessLevel(accountGUID: string): Observable<any> {
        const params = new HttpParams()
            .set('pAccountGUID', accountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getFieldAccessLevel}`, {params});
    }

    getAllMFIs(userGUID: string): Observable<any> {
        const params = new HttpParams()
            .set('pUserGuid', userGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.client.getAllMFIs}`, {params});
    }

    updateMFIInfo(data: any): Observable<any> {        
        return this.http.put(`${environment.apiUrl}/${urlPath.client.updateMFIInfo}`, data);
    }

    activateSubscription(data: IReqActivateSubscription): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.client.activateSubscription}`, data);
    }

    registerNewMFI(data: IReqCreateMfi): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.client.registerNewMFI}`, data);
    }

    saveUserDetails(data: IReqSaveUserDetail): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.client.saveUserDetails}`, data);
    }

    inactivateActivateUser(data: IReqInactivateActivateUser): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.client.inactivateActivateUser}`, data);
    }

}