import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

@Injectable({ providedIn: 'root' })
export class ReportService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    constructor(
        private http: HttpClient
    ) {}

    moveReportToDeleted(blobName: string, pShortURL: string, srcContainer: string) {
        const params = new HttpParams().set('blobName', blobName).set('pShortURL', pShortURL).set('srcContainer', srcContainer);
        return this.http.delete(`${environment.apiUrl}/${urlPath.report.moveReportToDeleted}`, {params});
    }

}