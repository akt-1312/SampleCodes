import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

@Injectable({ providedIn: 'root' })
export class FileService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    constructor(
        private http: HttpClient
    ) {}

    getUploadFileStatusDescriptionList(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.file.getUploadFileStatusDescriptionList}`);
    }

    list(pShortURL: string, subcontainer: string): Observable<any> {
        const params = new HttpParams().set('pShortURL', pShortURL).set('subcontainer', subcontainer);
        return this.http.get(`${environment.apiUrl}/${urlPath.file.list}`, {params});
    }

    getErrorInformation(subDirectory: string, fileName: string, containerName: string): Observable<any> {
        const params = new HttpParams().set('subDirectory', subDirectory).set('fileName', fileName).set('containerName', containerName);
        return this.http.get(`${environment.apiUrl}/${urlPath.file.getErrorInformation}`, {params});
    }
    
    upload(data: string, file: File): Observable<any> {
        const formData: FormData = new FormData();
        
        formData.append('data', data);
        formData.append('file', file);        
        return this.http.post(`${environment.apiUrl}/${urlPath.file.upload}`, formData, this.httpOptions);
    }

    delete(filename: string, pShortURL: string) {
        const params = new HttpParams().set('filename', filename).set('pShortURL', pShortURL);
        return this.http.delete(`${environment.apiUrl}/${urlPath.file.delete}`, {params});
    }

    download(filename: string, pShortURL: string, pFolderName: string): Observable<any> {
        const params = new HttpParams().set('filename', filename).set('pShortURL', pShortURL).set('pFolderName', pFolderName);
        return this.http.get(`${environment.apiUrl}/${urlPath.file.download}`, {params});
    }

}