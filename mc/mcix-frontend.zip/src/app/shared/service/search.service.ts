import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';


@Injectable({ providedIn: 'root' })
export class SearchService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    httpFormDataOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'multipart/form-data'
        })
    }

    constructor(
        private http: HttpClient
    ) {}

    getNRCDivisionTownshipValues(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.search.getNRCDivisionTownshipValues}`);
    }

    simpleSearch(req: any): Observable<any> {
        return this.http.post(`${environment.apiUrl}/${urlPath.search.simpleSearch}`, req, this.httpOptions);
    }

    bulkSearchOld(file: File, cacheKey: any): Observable<any> {
        const formData: FormData = new FormData();
        console.log(file, cacheKey)
        formData.append('file', file);
        formData.append('cacheKey', cacheKey);
        return this.http.post(`${environment.apiUrl}/${urlPath.search.bulkSearch}`, formData, this.httpFormDataOptions);
        // return this.http.post(`${environment.apiUrl}/${urlPath.search.bulkSearch}`, this.httpOptions);
    }

    bulkSearch(file: File, cacheKey: any): Observable<any> {
        const formData: FormData = new FormData();
    
        formData.append('file', file);
        formData.append('cacheKey', cacheKey);
    
        const req = new HttpRequest('POST', `${environment.apiUrl}/${urlPath.search.bulkSearch}`, formData, {
          reportProgress: true,
          responseType: 'json'
        });
    
        return this.http.request(req);
    }
    

}