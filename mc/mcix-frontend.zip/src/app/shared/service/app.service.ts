import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

@Injectable({ providedIn: 'root' })
export class AppService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    constructor(
        private http: HttpClient
    ) {}

    getDivisions(pAccountGUID: string, pUserID: string): Observable<any> {
        const params = new HttpParams().set('pAccountGUID', pAccountGUID).set('pUserID', pUserID);
        return this.http.get(`${environment.apiUrl}/${urlPath.app.getDivisions}`, {params});
    }

    getTownships(pDivisionCode: string, pAccountGUID: string, pUserID: string): Observable<any> {
        const params = new HttpParams().set('pDivisionCode', pDivisionCode).set('pAccountGUID', pAccountGUID).set('pUserID', pUserID);
        return this.http.get(`${environment.apiUrl}/${urlPath.app.getTownships}`, {params});
    }

    getReportingDateForCompanyProfile(): Observable<any> {
        return this.http.get(`${environment.apiUrl}/${urlPath.app.getReportingDateForCompanyProfile}`);
    }
    

}