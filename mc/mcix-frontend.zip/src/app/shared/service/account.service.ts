import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

import { IReqRegisterUser } from '../model/request/IReqRegisterUser';
import { IReqResetPasswordUser } from '../model/request/IReqResetPasswordUser';

@Injectable({ providedIn: 'root' })
export class AccountService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    constructor(
        private http: HttpClient
    ) {}

    changePassword(OldPassword: string, NewPassword: string, ConfirmPassword: string): Observable<any> {
        const params = new HttpParams()
            .set('OldPassword', OldPassword)
            .set('NewPassword', NewPassword)
            .set('ConfirmPassword', ConfirmPassword);
        return this.http.post(`${environment.apiUrl}/${urlPath.account.changePassword}`, {params});
    }   

    register(data: IReqRegisterUser): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.account.register}`, data);
    }

    resetPassword(data: IReqResetPasswordUser): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.account.resetPassword}`, data);
    }
    

}