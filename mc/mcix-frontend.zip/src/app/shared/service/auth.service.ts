import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';
import { Token } from '../model';
import { TokenStorageService } from './token-storage.service';
import { createOfflineCompileUrlResolver } from '@angular/compiler';

@Injectable({ providedIn: 'root' })
export class AuthService {
    private tokenSubject: BehaviorSubject<Token>;
    public token: Observable<Token>;

    constructor(
        private router: Router,
        private http: HttpClient,
        private tokenStorageService: TokenStorageService
    ) {     
        const tokenObj: Token = this.tokenStorageService.getToken();
        this.tokenSubject = new BehaviorSubject<Token>(tokenObj);
        this.token = this.tokenSubject.asObservable();
    }

    public get tokenValue(): Token {
        return this.tokenSubject.value;
    }

    login(username: string, password: string) {

        const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/x-www-form-urlencoded'
            })
        };

        let body = new URLSearchParams();
        body.set('username', username);
        body.set('password', password);
        body.set('grant_type', 'password');
        
        
        return this.http.post<any>(`${environment.apiUrl}/${urlPath.token}`, body.toString(), httpOptions)
            .pipe(map(tokenObj => {
                console.log('token one', tokenObj);               

                // store user details and jwt token in local storage to keep user logged in between page refreshes
                this.tokenStorageService.saveToken(tokenObj.access_token, tokenObj.userName);

                this.http.get<any>(`${environment.apiUrl}/${urlPath.client.getCurrentUser}`).subscribe(data => {
                    console.log(data, 'data another')
                    const menuIds = data.AccessMenuList.split(',').map(item => item.trim());
                    this.tokenStorageService.saveUser(data.AccountGUID, data.UserGUID, data.UserRole, menuIds);
                    console.log('success menu list')

                    const returnUrl = data.IsFirstTimeLogin === 'true' ? '/reset-password' : '/home';
                    this.router.navigateByUrl(returnUrl);

                    this.tokenSubject.next(tokenObj);
                    return tokenObj;
                })

                
            }));
    }
    
    logout() {
        // remove user from local storage to log user out
        this.tokenStorageService.clearToken();
        this.tokenSubject.next(new Token());
        this.router.navigate(['/login']);
    }
}