import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

@Injectable({ providedIn: 'root' })
export class DashboardService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    constructor(
        private http: HttpClient
    ) {}

    getOverlapBorrowers(
        pDivisionCode: string, 
        pTownshipCode: string, 
        pCategory: string, 
        pReportingYYYYMM: string,
        pLoanCount: string
    ): Observable<any> {
        let params = new HttpParams()
            .set('pDivisionCode', pDivisionCode)
            .set('pTownshipCode', pTownshipCode)
            .set('pCategory', pCategory)
            .set('pReportingYYYYMM', pReportingYYYYMM)
            .set('pLoanCount', pLoanCount);

            if(pLoanCount) {
                params = params.append('pLoanCount', pLoanCount);
            }
        
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getOverlapBorrowers}`, {params});
    }

    getOverlapLoanCount(pDivisionCode: string, pTownshipCode: string, pReportingYYYYMM: string): Observable<any> {
        const params = new HttpParams()
            .set('pDivisionCode', pDivisionCode)
            .set('pTownshipCode', pTownshipCode)
            .set('pReportingYYYYMM', pReportingYYYYMM);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getOverlapLoanCount}`, {params});
    }

    getInquiryByAccount(pAccountGUID: string): Observable<any> {
        const params = new HttpParams().set('pAccountGUID', pAccountGUID);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getInquiryByAccount}`, {params});
    }

    getSearchRecordByUser(pDivisionCode: string, pTownshipCode: string, pReportingYYYYMM: string, pUserID: string): Observable<any> {
        const params = new HttpParams()
            .set('pDivisionCode', pDivisionCode)
            .set('pTownshipCode', pTownshipCode)
            .set('pReportingYYYYMM', pReportingYYYYMM)
            .set('pUserID', pUserID);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getSearchRecordByUser}`, {params});
    }

    getPenetrationRate(pDivisionCode: string, pUserID: string, pReportingYYYYMM_From: string, pReportingYYYYMM_To: string, ): Observable<any> {
        const params = new HttpParams()
            .set('pDivisionCode', pDivisionCode)
            .set('pUserID', pUserID)
            .set('pReportingYYYYMM_From', pReportingYYYYMM_From)
            .set('pReportingYYYYMM_To', pReportingYYYYMM_To);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getPenetrationRate}`, {params});
    }

    getOverlapBorrowersTrend(pDivisionCode: string, pTownshipCode: string): Observable<any> {
        const params = new HttpParams()
            .set('pDivisionCode', pDivisionCode)
            .set('pTownshipCode', pTownshipCode);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getOverlapBorrowersTrend}`, {params});
    }

    getActiveClientMonthlyUpload(): Observable<any> {        
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getActiveClientMonthlyUpload}`);
    }

    getWriteOffClientMonthlyUpload(): Observable<any> {        
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getWriteOffClientMonthlyUpload}`);
    }

    getPublicationListBlobs(): Observable<any> {        
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getPublicationListBlobs}`);
    }
    
    getCreditReport(uniqueId: string): Observable<any> {
        const params = new HttpParams()
            .set('uniqueId', uniqueId);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getCreditReport}`, {params});
    }

    getRptUserTrend(pUniqueID: string): Observable<any> {
        const params = new HttpParams()
            .set('pUniqueID', pUniqueID);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getRptUserTrend}`, {params});
    }

    getBase64BlobPdfData(fileName: string, containerName: string): Observable<any> {
        const params = new HttpParams()
            .set('fileName', fileName)
            .set('containerName', containerName);
        return this.http.get(`${environment.apiUrl}/${urlPath.dashboard.getBase64BlobPdfData}`, {params});
    }

}