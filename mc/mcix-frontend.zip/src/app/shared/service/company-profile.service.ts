import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { urlPath } from 'src/app/shared/config/url-path';

import { IReqGetCompanyProfile } from '../model/request/IReqGetCompanyProfile';

@Injectable({ providedIn: 'root' })
export class CompanyProfileService {

    httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
    }

    constructor(
        private http: HttpClient
    ) {}   

    getCompanyProfile(data: IReqGetCompanyProfile): Observable<any> {        
        return this.http.post(`${environment.apiUrl}/${urlPath.company_profile.getCompanyProfile}`, data);
    }    

    getCompanyProfileDetails(pLGUID: string, pReportingDate: string, pShowOnlyBadFlag: string): Observable<any> {
        const params = new HttpParams()
            .set('pLGUID', pLGUID)
            .set('pReportingDate', pReportingDate)
            .set('pShowOnlyBadFlag', pShowOnlyBadFlag);
        return this.http.get(`${environment.apiUrl}/${urlPath.company_profile.getCompanyProfileDetails}`, {params});
    }
    

}