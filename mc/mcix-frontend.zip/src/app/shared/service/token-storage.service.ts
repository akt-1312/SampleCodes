import { Injectable } from '@angular/core';
import { Token, User } from '../model';

const TOKEN_KEY = 'mcix-token';
const USER_KEY = 'mcix-user';
const LANG_KEY = 'mcix-lang';

@Injectable({
    providedIn: 'root'
})
export class TokenStorageService {

    constructor() { }

    public saveToken(access_token: string, userName: string): void {
        const tokenObj : Token = { access_token, userName  }
        window.sessionStorage.removeItem(TOKEN_KEY);
        window.sessionStorage.setItem(TOKEN_KEY, JSON.stringify(tokenObj));
    }
    
    public getTokend(): string | null {
        return window.sessionStorage.getItem(TOKEN_KEY);
    }

    public saveUser(AccountGUID: string, UserGUID: string, UserRole: string, AccessMenuList: string[]): void {
        const userObj: User = { AccountGUID, UserGUID, UserRole, AccessMenuList }
        window.sessionStorage.removeItem(USER_KEY);
        window.sessionStorage.setItem(USER_KEY, JSON.stringify(userObj));
    }
    
    public getToken(): Token {
        const tokenStr = window.sessionStorage.getItem(TOKEN_KEY);
        const token: Token = tokenStr !== null ? JSON.parse(tokenStr) : new Token();
        return token;
    }

    public isLoggedIn(): boolean {
        return this.getToken().access_token ? true: false;
    }

    public getAccessToken(): string {      
        return this.getToken().access_token               
    }

    public getUserName(): string {      
        return this.getToken().userName;            
    }

    private getUser(): User {
        const userStr = window.sessionStorage.getItem(USER_KEY);
        const user: User = userStr !== null ? JSON.parse(userStr) : new User();
        return user;
    }

    public getAccountGUID(): string {      
        return this.getUser().AccountGUID;                
    }

    public getUserGUID(): string {      
        return this.getUser().UserGUID;                
    }

    public getUserRole(): string {      
        return this.getUser().UserRole;
    }

    public getAccessMenuList(): string[] {      
        return this.getUser().AccessMenuList;  
    }    

    public saveLang(lang: string): void {
        window.sessionStorage.removeItem(LANG_KEY);
        window.sessionStorage.setItem(LANG_KEY, lang);
    }

    public getLang() {
        return window.sessionStorage.getItem(LANG_KEY)
    }

    public clearToken() {
        window.sessionStorage.removeItem(TOKEN_KEY);
        window.sessionStorage.removeItem(USER_KEY);
        window.sessionStorage.removeItem(LANG_KEY);
    }

}
