import { IResCodeName } from "../model/response/IResCodeName";

export function getLastMonths(n: number) {
    var months: IResCodeName[] = [];
    var today = new Date();
    var year = today.getFullYear();
    var month: number = today.getMonth() + 1;
    var i = 0;
    while (i < n) {
        months.push({ Code: `${year}${month.toString().padStart(2, '0')}`, Name: `${year}-${month.toString().padStart(2, '0')}` });
        if (month == 1) {
            month = 12;
            year--;
        } else {
            month--;
        }
        i++;
    }
    return months;
}