export interface IUpload {    
    institutionData: string[];    
    monthOneData: number[];
    monthTwoData: number[];
    monthThreeData: number[];
    monthFourData: number[];
    monthFiveData: number[];
    monthSixData: number[];
}