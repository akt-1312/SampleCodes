export class Township {
    ID: number;
    Descriptions: string;

    constructor() {
        this.ID = 0;
        this.Descriptions = 'Select one';
    }
}