export class User {    
    AccountGUID: string;
    UserGUID: string;
    UserRole: string;
    AccessMenuList: string[];

    constructor() {
        this.AccountGUID = '';
        this.UserGUID = '';
        this.UserRole = '';
        this.AccessMenuList = [];
    }
}