export interface IMonthLabel {    
    monthOne: string;
    monthTwo: string;
    monthThree: string;
    monthFour: string;
    monthFive: string;
    monthSix: string;
}