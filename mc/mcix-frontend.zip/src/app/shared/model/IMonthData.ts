export interface IMonthData {    
    institutionData: string[];
    loanCountData: string[];
    institutionLCountData: string[];
    monthOneData: number[];
    monthTwoData: number[];
    monthThreeData: number[];
    monthFourData: number[];
    monthFiveData: number[];
    monthSixData: number[];
}