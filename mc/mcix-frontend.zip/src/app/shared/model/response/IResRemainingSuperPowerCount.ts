export interface IResRemainingSuperPowerCount {
    NumberofRemainingPowerUserCount: number;
    NumberofRemainingSuperUserCount: number;
}