export interface IResBulkSearch {    
    UniqueID: string;
    NRC: string;
    FullName: string;
    DOB: string;
    FatherFullName: string;
    Active: string;
    Location: string;
    Flag: any;
}