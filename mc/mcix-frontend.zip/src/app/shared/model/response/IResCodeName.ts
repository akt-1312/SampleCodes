export interface IResCodeName {    
    Code: string;
    Name: string;
}