export interface IResSubscription {    
    PackageGUID: string;
    AccountGUID: string;
    StartDate: string;
    EndDate: string;
    PackageName: string;
    ModulePattern: string;
}