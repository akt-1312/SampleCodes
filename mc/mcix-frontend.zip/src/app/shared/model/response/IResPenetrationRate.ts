export interface IResPenetrationRate {    
    Division: string;
    Township: string;
    NoOfBorrowers: string;
    NoOfHouseholds: string;
    AdjustedPenetrationRate: string;
    Month: string;
}