export interface IResCompanyProfile {    
    LGUID: string;
    MFI: string;
    Month: string;
    NoOfActiveBorrowersStated: number;
    NoOfActiveTownshipsStated: number;
    NoOfActiveBorrowerUploaded: number;
    NoOfActiveTownshipUploaded: number;
    NoOfWriteOffBorrowersStated: number;
    TotalPrincipalWriteOffStated: number;
    Percentage: number;
}