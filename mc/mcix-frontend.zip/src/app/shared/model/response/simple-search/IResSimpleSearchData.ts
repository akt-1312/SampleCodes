export interface IResSimpleSearchData {
    UniqueID: string;
    NRC: string;
    FullName: string;
    DOB: string;
    FatherFullName: string;
    Location: string;
    Flag: any;
    Active: string;
}