export interface Flag {
    WriteOff?: number;
    Overlap?: number;
    Delinquent?: number;
    CERP?: number;
  }