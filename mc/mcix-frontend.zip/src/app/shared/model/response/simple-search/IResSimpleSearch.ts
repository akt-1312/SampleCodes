import { IResSimpleSearchData } from "./IResSimpleSearchData";

export interface IResSimpleSearch {
    Data: IResSimpleSearchData[];
    MessageDtm: string;
    SubscriptionID: string;
    CallerIP: string;
    URI: string;
    ResponseMessage: string;
}