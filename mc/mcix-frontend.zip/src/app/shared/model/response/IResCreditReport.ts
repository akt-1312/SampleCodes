export interface IResCreditReport {
    Data:            Data;
    MessageDtm:      string;
    SubscriptionID:  string;
    CallerIP:        string;
    URI:             string;
    ResponseMessage: string;
}

export interface Data {
    BorrowerInfo:       BorrowerInfo;
    ActiveLoanStatus:   string;
    ActiveLoans:        ActiveLoan[];
    WriteOffLoanStatus: string;
    WriteOffLoans:      WriteOffLoan[];
    CreditScore:        CreditScore;
    InquiryStatus:      string;
    Inquiries:          Inquiry[];
}

export interface ActiveLoan {
    ReportingDate:              Date;
    LoanGUID:                   string;
    Institution:                string;
    Division:                   string;
    Township:                   string;
    DisbursedDate:              Date;
    DisbursedAmount:            string;
    PrincipalOutstandingAmount: string;
    TotalOutstandingAmount:     string;
    PrincipalOverdueAmount:     string;
    TotalOverdueAmount:         string;
    DaysInDelay:                string;
    UpdatedDtm:                 string;
    Status:                     string;
    DisplayValues:              string;
}

export interface BorrowerInfo {
    MainIdentifier: string;
    Name:           string;
    NRC:            string;
    Gender:         string;
    DOB:            string;
    FatherName:     string;
    Address:        string;
    LastUpdatedDtm: string;
    PrintedDtm:     string;
    Active:         string;
    Flag:           string;
}

export interface CreditScore {
    Score: string;
    Class: string;
    Note:  string;
}

export interface Inquiry {
    InquiryDate: string;
    Institution: string;
    NoOfInquiry: string;
}

export interface WriteOffLoan {
    ReportingDate:           Date;
    ClaimGUID:               string;
    Institution:             string;
    Division:                string;
    Township:                string;
    DisbursedDate:           Date;
    DisbursedAmount:         string;
    WriteOffDate:            Date;
    PrincipalWriteOffAmount: string;
    Note:                    string;
    UpdatedDtm:              string;
    Status:                  string;
    DisplayValues:           string;
}
