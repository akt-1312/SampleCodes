export interface IResAuditDetailHeader {    
    UserID: string;
    MFIName: string;
    StartDate: string;
    EndDate: string;
    NoOfNRCSearched: string;
    NoofTownshipsSearched: string;
    NoOfOffHourSearches: string;
}