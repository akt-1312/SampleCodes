export interface IResLandingPageInfo {
    Data: Data
    MessageDtm: string
    SubscriptionID: string
    CallerIP: string
    URI: string
    ResponseMessage: string
  }
  
  export interface Data {
    Main: Main[]
    Others: Other[]
    History: History[]
  }
  
  export interface Main {
    ImageName: string
    Type: string
    Date: string
    Title: string
    Details: string
  }
  
  export interface Other {
    Type: string
    Date: string
    Title: string
    Details: string
  }
  
  export interface History {
    Type: string
    Date: string
    Title: string
    Details: string
  }
  