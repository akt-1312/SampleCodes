import { IResAuditDetailHeader } from "./IResAuditDetailHeader";
import { IResAuditDetailBody } from "./IResAuditDetailBody";

export interface IResAuditDetail {    
    header: IResAuditDetailHeader;
    body: IResAuditDetailBody[];
}