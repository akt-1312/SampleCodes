export interface IResTownship {    
    ID: number;
    Descriptions: string;
}