export interface IResTrendReport {    
    Month: string;
    Active: number;
    WriteOff: number;
    Inquiry: number;
    ActiveInstitution: string;
    WriteOffInstitution: string;
}