export interface IResMFI {    
    AccountGUID: string;
    AccountName: string;
    NumberofRemainingPowerUserCount: string;
    NumberofRemainingSuperUserCount: string;
    LGUID: string;
    LenderName: string;
}