export interface IResCompanyStatsDetail {    
    Division: string;
    Township: string;
    NoOfActiveBorrowerStated: number;
    NoOfActiveBorrowerUploaded: number;
    Percentage: number;
    BadFlag: string;
    MFI: string;
}