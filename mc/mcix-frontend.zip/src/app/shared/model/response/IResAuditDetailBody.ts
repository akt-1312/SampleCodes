export interface IResAuditDetailBody {   
    UserID: string;
    MFIName: string;
    SearchedDate: string;
    SearchedTime: string;
    SearchedNRC: string;
    InstitutionName: string;
    Division: string;
    Township: string;
}