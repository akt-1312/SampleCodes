export interface IResOverlapLoanCount {    
    LoanCount: string;
    Description: string;
    RecordCount: string;
}