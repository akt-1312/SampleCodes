export interface IResAuditOverview {    
    UserName: string;
    NoOfNRCSearched: string;
    UserGUID: string;
}