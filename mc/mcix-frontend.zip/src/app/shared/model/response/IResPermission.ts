export interface IResPermission{    
    FieldName: string;
    AccessFlag: string;
}