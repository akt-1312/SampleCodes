export interface IResAppUser {    
    Email: string;
    UserName: string;
    RoleName: string;
    UserGUID: string;
    CreatedDtm: string;
    UpdatedDtm: string;
    IsActive: string;
    UpdatedBy: string;
}