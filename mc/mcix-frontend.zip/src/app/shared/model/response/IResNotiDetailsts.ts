export interface IResNotiDetails {    
    NotificationType: string;
    GUID: string;
    NRC: string;
    Institution: string;
    Location: string;
    FullName: string;
    Gender: string;
    FatherFullName: string;
    Telephone: string;
    Address: string;
    AddressLine2?: any;
    Loan: string;
    DisbursedDtm?: any;
    ClaimSubmittedDtm?: any;
    Note?: any;
    CreatedDtm: string;
    UpdatedDtm: string;
    UniqueID: string;
}