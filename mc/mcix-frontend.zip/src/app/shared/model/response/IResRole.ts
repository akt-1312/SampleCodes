export interface IResRole {    
    Id: string;
    Name: string;
}