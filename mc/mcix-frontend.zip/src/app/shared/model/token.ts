export class Token {
    access_token: string;
    userName: string;

    constructor() {
        this.access_token = '';
        this.userName = '';
    }
}