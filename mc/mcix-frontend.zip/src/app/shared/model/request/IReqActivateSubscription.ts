export interface IReqActivateSubscription {    
    pAppUserGUID: string;
    pMFIAccountId: string;
    pStartDate: string;
    pEndDate: string;
}