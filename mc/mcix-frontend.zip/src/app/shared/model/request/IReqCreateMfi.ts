export interface IReqCreateMfi {       
    accountGUID: string;
	accountName: string;
	lenderName: string;
	shortUrl: string;
	contactTitle: string;
	itContactTitle: string;
	itContactName: string;
	fullName: string;
	addressLine: string;
	contactEmail_1: string;
	contactEmail_2: string;
	contactLandline_1: string;
	contactLandline_2: string;
	contactMobile_1: string;
	contactMobile_2: string;
	comments: string;
	clientCount: number;
	pAppUserGUID: string;
}