export interface IReqResetPasswordUser {       
    UserId: string;
	Password: string;
	ConfirmPassword: string;
}