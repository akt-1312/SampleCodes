export interface IReqGetCompanyProfile {       
    pLGUIDstringarray: string;
	pReportingYYYYMM_From: string;
	pReportingYYYYMM_To: string;
}