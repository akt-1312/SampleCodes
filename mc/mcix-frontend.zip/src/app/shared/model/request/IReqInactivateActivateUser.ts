export interface IReqInactivateActivateUser {  
	pUserGUID: string;
	pAppUserGUID: string;
	pIsActive: string;
}