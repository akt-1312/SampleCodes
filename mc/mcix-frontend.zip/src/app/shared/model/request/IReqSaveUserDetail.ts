export interface IReqSaveUserDetail {       
    pEmail: string;
	pAppUserGUID: string;
	pAccountGUID: string;
	pPhoneNumber: string;
    pRoleID: string;
	pIsActive: string;
	pUserLocationJsonStr: string;
}