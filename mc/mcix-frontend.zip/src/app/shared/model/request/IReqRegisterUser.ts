export interface IReqRegisterUser {       
    Email: string;
	Password: string;
	ConfirmPassword: string;
	PasswordConfirm: string;
}