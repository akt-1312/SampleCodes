import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from "angular-datatables";
import { ShareModule } from '../shared/module/share/share.module';

import { AccountRoutingModule } from './account-routing.module';
import { AccountInfoComponent } from './account-info/account-info.component';
import { PermissionsComponent } from './permissions/permissions.component';


@NgModule({
  declarations: [
    AccountInfoComponent,
    PermissionsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ShareModule,
    DataTablesModule,
    AccountRoutingModule
  ]
})
export class AccountModule { }
