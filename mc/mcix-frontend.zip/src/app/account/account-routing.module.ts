import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { AccountInfoComponent } from './account-info/account-info.component';
import { PermissionsComponent } from './permissions/permissions.component';

const routes: Routes = [
  { path: '', redirectTo: '/account/info', pathMatch: 'full' },
  { path: 'info', component:  AccountInfoComponent, canActivate: [AuthGuard], data: {menuId: '42'} },
  { path: 'permissions', component:  PermissionsComponent, canActivate: [AuthGuard], data: {menuId: '43'} }      
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
