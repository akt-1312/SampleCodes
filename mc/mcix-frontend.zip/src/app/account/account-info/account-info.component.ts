import { IReqAccountInfo } from './../../shared/model/request/IReqAccountInfo';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ClientService } from 'src/app/shared/service/client.service';
import { ToastrService } from 'ngx-toastr';

import { IResAccountInfo } from 'src/app/shared/model/response/IResAccountInfo';
import { IResSubscription } from 'src/app/shared/model/response/IResSubscription';

@Component({
  selector: 'app-account-info',
  templateUrl: './account-info.component.html',
  styleUrls: ['./account-info.component.scss']
})
export class AccountInfoComponent implements OnInit {

  accountInfo: IResAccountInfo;
  updateFields: IReqAccountInfo;
  subscriptions: IResSubscription[] = []
  loading = false;
  btnLoading = false;
  submitted = false;
  error = '';

  accountInfoForm: FormGroup = new FormGroup({
    itContactName: new FormControl(),
    contactEmail_2: new FormControl(),
    contactLandline_2: new FormControl(),
    contactMobile_2: new FormControl()

  });

  constructor(
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    

    this.getAccountInfo();
    this.getSubscriptions();
  }

  get f() { return this.accountInfoForm.controls; } 

  getAccountInfo(): void {
    this.loading = true;
    this.clientService.getAccountInfo(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        console.log('getAccountInfo', data);
        this.accountInfo = data;

        this.setFormValue(this.accountInfo);

        this.loading = false;
      },
      err => {
        console.log('getAccountInfo', err);
        this.loading = false;
      }
    )
  }

  setFormValue(data: IResAccountInfo) {
    this.accountInfoForm = this.formBuilder.group({   
      itContactName: [data.ITContactName, [Validators.required]],
      contactEmail_2: [data.ContactEmail2, [Validators.required]],
      contactLandline_2: [data.ContactLandline2, [Validators.required]],
      contactMobile_2: [data.ContactMobile2, [Validators.required]]
    });
  }

  getSubscriptions(): void {
    this.loading = true;
    this.clientService.getSubscriptions(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        this.subscriptions = data
        console.log('getSubscriptions', data);
        this.loading = false;
      },
      err => {
        console.log('getSubscriptions', err);
        this.loading = false;
      }
    )
  }

  onSubmit() {
    this.submitted = true;

    if (this.accountInfoForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.updateFields = {
      accountGUID: this.accountInfo.AccountGUID,
      accountName: this.accountInfo.AccountName,
      lenderName: this.accountInfo.LenderName,
      shortUrl: this.accountInfo.ShortURL,
      contactTitle: this.accountInfo.ContactTitle,
      itContactTitle: this.accountInfo.ITContactTitle,
      itContactName: this.accountInfo.ITContactName,
      fullName: this.accountInfo.ContactFullName,
      addressLine: this.accountInfo.AddressLine1,
      contactEmail_1: this.accountInfo.ContactEmail1,
      contactEmail_2: this.accountInfo.ContactEmail2,
      contactLandline_1: this.accountInfo.ContactLandline1,
      contactLandline_2: this.accountInfo.ContactLandline2,
      contactMobile_1: this.accountInfo.ContactMobile1,
      contactMobile_2: this.accountInfo.ContactMobile2,
      comments: this.accountInfo.Comments,
      clientCount: this.accountInfo.ClientCountAtSignUp,
      pAppUserGUID: this.tokenStorageService.getUserGUID(),
      isActive: this.accountInfo.isActive,
      accountRefNumber: this.accountInfo.AccountRefNumber
    }

    this.clientService.updateMFIInfo(this.updateFields).subscribe(
      data => {
        console.log(data);  
        this.btnLoading = false;
        this.toastr.success('Success.');      
      }, 
      err => {
        console.log(err, 'error');
        this.btnLoading = false;
      }
    )
    
  }

}
