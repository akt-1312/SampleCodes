import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';

import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ClientService } from 'src/app/shared/service/client.service';

import { IResPermission } from 'src/app/shared/model/response/IResPermission';

@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.scss']
})
export class PermissionsComponent implements OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  permissionData: IResPermission[] = [];

  loading = false;

  constructor(
    private clientService: ClientService,
    private tokenStorageService: TokenStorageService
  ) { }

  ngOnInit(): void {
    this.dtOptions = {
      columns: [
        
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true }
        
      ],
      responsive: true
      
    }; 

    this.getFieldAccessLevel();
  }

  

  getFieldAccessLevel(): void {
    this.loading = true;
    this.clientService.getFieldAccessLevel(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        console.log('getFieldAccessLevel', data);
        this.permissionData = data; 
        this.loading = false;
      },
      err => {
        console.log('getFieldAccessLevel', err);
        this.loading = false;
      }
    )
  }

}
