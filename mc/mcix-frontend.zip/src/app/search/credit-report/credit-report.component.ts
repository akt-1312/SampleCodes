import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { DashboardService } from 'src/app/shared/service/dashboard.service';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { Subject } from 'rxjs';

import { menuIds } from 'src/app/shared/config/menu-ids';
import { IResCreditReport } from 'src/app/shared/model/response/IResCreditReport';
import { IResTrendReport } from 'src/app/shared/model/response/IResTrendReport';
import { groupBy } from 'src/app/shared/helper/groupby';

@Component({
  selector: 'app-credit-report',
  templateUrl: './credit-report.component.html',
  styleUrls: ['./credit-report.component.scss']
})
export class CreditReportComponent implements OnInit, OnDestroy {

  menuList: String[] = []

  dtOptions: any = {};
  dtTrigger: Subject<any> = new Subject<any>();

  loading = false;
  errorMsg = ''; 

  MainIdentifier = '';
  LastUpdatedDtm = '';
  PrintedDtm = '';
  name = '';
  alsoKnowAs = '';

  flag: any;
  creditReportData: IResCreditReport;
  trendReportData: IResTrendReport[];

  
  activeLoansData: any = [];
  activeLoansDataPrint: any = [];
  writeOffLoansData: any = [];
  writeOffLoansDataPrint: any = [];

  activeChartOptions: ChartOptions = {responsive: true, scales: {yAxes: [{ticks: {beginAtZero: true}}]}};
  activeChartLabels: Label[] = [];
  activeChartType: ChartType = 'line';
  activeChartLegend = true;
  activeChartPlugins = [];
  activeChartData: ChartDataSets[] = [];  
  activeChartColors: Color[] = [
    { borderColor: '#4e73df',  backgroundColor: 'rgba(255,255,255,0.1)' },
    { borderColor: '#1cc88a',  backgroundColor: 'rgba(255,255,255,0.1)' }
  ]

  inquiryChartOptions: ChartOptions = {responsive: true, scales: {yAxes: [{ticks: {beginAtZero: true}}]}};
  inquiryChartLabels: Label[] = [];
  inquiryChartType: ChartType = 'line';
  inquiryChartLegend = true;
  inquiryChartPlugins = [];
  inquiryChartData: ChartDataSets[] = [];  
  inquiryChartColors: Color[] = [{ borderColor: '#fd7e14',  backgroundColor: 'rgba(255,255,255,0.1)' }]

  constructor(
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private dashboardService: DashboardService,
    private tokenStorageService: TokenStorageService
  ) { }

  ngOnInit(): void {

    this.getAccessMenuList();

    this.dtOptions[0] = {
      paging:   false,
      ordering: false,
      info:     false,
      searching: false,
      columns: [        
        { "searchable": false, orderable: false, visible: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false }        
      ],
      responsive: true,
      rowGroup: true
    }

    

    this.dtOptions[1] = {
      paging:   false,
      ordering: false,
      info:     false,
      searching: false,
      columns: [        
        { "searchable": false, orderable: false, visible: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false },
        { "searchable": false, orderable: false }       
      ],
      responsive: true,
      rowGroup: true
    }

    

    this.route.params.subscribe(params => { 
      console.log(params.id)
      this.getCreditReport(params.id);
      this.getRptUserTrend(params.id)
    })
  }

  getAccessMenuList() {
    this.menuList = this.tokenStorageService.getAccessMenuList();
  }  

  checkMenuIds(menuRootItem: string, menuItem: string) {
    return this.menuList.indexOf(menuIds[menuRootItem][menuItem]) !== -1;
  }

  getCreditReport(uniqueId: string): void {
    this.loading = true;
    this.dashboardService.getCreditReport(uniqueId).subscribe(data => {
        
      

      this.MainIdentifier = data.Data.BorrowerInfo.MainIdentifier;
      this.LastUpdatedDtm = data.Data.BorrowerInfo.LastUpdatedDtm;
      this.PrintedDtm = data.Data.BorrowerInfo.PrintedDtm;
      const strName = data.Data.BorrowerInfo.Name;
      if (strName) {
        const [first, ...rest] = strName.split(',');      
        this.name = first;
        this.alsoKnowAs = rest.join(', ');
      }
      

      const arrFlag = JSON.parse(data.Data.BorrowerInfo.Flag)
      this.flag = arrFlag[0]

      this.activeLoansData = data.Data.ActiveLoans;
      this.writeOffLoansData = data.Data.WriteOffLoans;


      const ActiveLoans = data.Data.ActiveLoans;
      if (ActiveLoans) {
        const groupByActiveLoans = groupBy(ActiveLoans, (d) => d.Institution)   
        const labelActiveLoans  = Object.keys(groupByActiveLoans);
        console.log(labelActiveLoans, 'labels')

        const dataSetActiveLoans :any = []
        if (labelActiveLoans.length > 0) {
        
          labelActiveLoans.forEach((item, index) => {
            console.log(item, index)
            const obj = { label: labelActiveLoans[index], data: groupByActiveLoans[labelActiveLoans[index]].map(item => item) }
            dataSetActiveLoans.push(obj)    
          })
          
        }
        this.activeLoansDataPrint = dataSetActiveLoans;
      }

      //writeOffLoansData

      const WriteOffLoans = data.Data.WriteOffLoans;
      if (WriteOffLoans) {
        console.log(WriteOffLoans, 'WriteOffLoans')
        const groupByWriteOffLoans = groupBy(WriteOffLoans, (d) => d.Institution)   
        const labelWriteOffLoans  = Object.keys(groupByWriteOffLoans);
        console.log(labelWriteOffLoans, 'labels')

        const dataSetWriteOffLoans :any = []
        if (labelWriteOffLoans.length > 0) {
        
          labelWriteOffLoans.forEach((item, index) => {
            console.log(item, index)
            const obj = { label: labelWriteOffLoans[index], data: groupByWriteOffLoans[labelWriteOffLoans[index]].map(item => item) }
            dataSetWriteOffLoans.push(obj)    
          })
          
        }
        this.writeOffLoansDataPrint = dataSetWriteOffLoans;
      }
      
      this.creditReportData = data;    
      this.loading = false;
      this.dtTrigger.next();
    },
    err => {
      this.errorMsg = err;
      this.loading = false;
    })
  }

  getRptUserTrend(uniqueId: string): void {
    this.loading = true;
    this.dashboardService.getRptUserTrend(uniqueId).subscribe(data => {
      this.trendReportData = data;
      console.log(this.trendReportData, 'trendReportData')   

      const months = data.map(item => item.Month)
      const active = data.map(item => item.Active)
      const writeoff = data.map(item => item.WriteOff)
      const inquiry = data.map(item => item.Inquiry)
      const activeDataSet = [
        { data: active, label: 'Active' },
        { data: writeoff, label: 'WriteOff' }
      ]

      const inquiryDataSet = [
        { data: inquiry, label: 'Inquiry' }
      ]
      
      console.log(months, 'months', active, writeoff)

      this.activeChartLabels = months
      this.activeChartData = activeDataSet

      this.inquiryChartLabels = months
      this.inquiryChartData = inquiryDataSet

      this.loading = false;
    },
    err => {
      this.errorMsg = err;
      this.loading = false;
    })
  }

  changeDateFormat(date: string): string {
    return moment(new Date(date)).format("MMM YYYY")
  }

  print(): void {    
    window.print()
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
