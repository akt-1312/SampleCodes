
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ActivatedRoute  } from "@angular/router";
import { Observable, of, Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';

import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ClientService } from 'src/app/shared/service/client.service';
import { SearchService } from 'src/app/shared/service/search.service';
import { ToastrService } from 'ngx-toastr';
import { IResTownship } from 'src/app/shared/model/response/IResTownship';
import { IResSimpleSearchData } from 'src/app/shared/model/response/simple-search/IResSimpleSearchData';
import { catchError, finalize, map  } from 'rxjs/operators';
@Component({
  selector: 'app-simple-search',
  templateUrl: './simple-search.component.html',
  styleUrls: ['./simple-search.component.scss']
})
export class SimpleSearchComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  simpleSearchData: IResSimpleSearchData[] = [];
 

  loadingTownships = false;
  townships$: Observable<IResTownship[]>;
  
  

  searchForm: FormGroup = new FormGroup({
    div_township: new FormControl(),
    nrc: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  constructor(
    private route: ActivatedRoute, 
    private formBuilder: FormBuilder,
    private clientService: ClientService,
    private searchService: SearchService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
    ) {}

  ngOnInit(): void {  

    this.dtOptions = {     
      columns: [       
        { "searchable": false, orderable: false },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": false, orderable: false },
      ],
      order: [[ 3, 'asc' ]],
      responsive: true      
    }; 
    
    this.searchForm = this.formBuilder.group({
      div_township: [null],
      nrc: ['', [
        Validators.required, 
        Validators.minLength(5)]
      ]
    });

    

    this.getCurrentUser();
    this.getNRCDivisionTownshipValues();
    this.getQueryParams();

    
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  get f() { return this.searchForm.controls; }  

  getCurrentUser(): void {   

    this.clientService.getCurrentUser().subscribe(
      data => {
        const menuIds = data.AccessMenuList.split(',').map(item => item.trim());
        console.log('getCurrentUser', data, menuIds);   
          
        this.tokenStorageService.saveUser(data.AccountGUID, data.UserGUID, data.UserRole, menuIds);
      },
      err => {
        console.log('getCurrentUser', err);
      }
    )
  }

  getNRCDivisionTownshipValues(): void {
    this.loadingTownships = true;      
    this.townships$ = this.searchService
                .getNRCDivisionTownshipValues()
                .pipe(           
                  // map(response => response.filter(item => item.ID !== 0)),         
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>{
                    this.loadingTownships=false;

                    
                  
                  })
                );
  }

  getQueryParams(): void {
    this.route.queryParamMap.subscribe((params) => {
      const t = params.get('t');
      if (t) {
        this.searchForm.patchValue({
          nrc: t
        })
        this.onSubmit();
      }
    })
  }

  

  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;    

    let req = {}
    if (this.f.div_township.value === null || this.f.div_township.value === 0) {
      req = { nrc: this.f.nrc.value }
    } else {
      req = { div_township: this.f.div_township.value, nrc: this.f.nrc.value }
    }

    console.log('req is ', req);

    this.searchService.simpleSearch(req).subscribe(
      data => {
        console.log(data);
        if (data.Data.length>0) {               

          data.Data.forEach(d => d.Flag = JSON.parse(d.Flag)[0])

          this.simpleSearchData = data.Data;
          this.btnLoading = false;
          this.toastr.success(data.ResponseMessage);
          this.rerender()
        } else {
          this.btnLoading = false;
          this.toastr.error(data.ResponseMessage);
        }
      }, 
      err => {
        console.log(err, 'error');
        this.btnLoading = false;
      }
    )

  }

}
