import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from "angular-datatables";
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { SearchRoutingModule } from './search-routing.module';
import { ShareModule } from '../shared/module/share/share.module';
import { ChartsModule } from 'ng2-charts';
import { SimpleSearchComponent } from './simple-search/simple-search.component';
import { BulkSearchComponent } from './bulk-search/bulk-search.component';
import { CreditReportComponent } from './credit-report/credit-report.component';

@NgModule({
  declarations: [
    SimpleSearchComponent,
    BulkSearchComponent,
    CreditReportComponent
  ],
  imports: [
    CommonModule,
    SearchRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    ShareModule,
    NgSelectModule,
    ChartsModule,
    TooltipModule.forRoot()
  ]
})
export class SearchModule { }
