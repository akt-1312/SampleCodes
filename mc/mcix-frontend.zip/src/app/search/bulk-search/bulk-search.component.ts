import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import * as moment from 'moment';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { SearchService } from 'src/app/shared/service/search.service';
import { ToastrService } from 'ngx-toastr';

import { IResBulkSearch } from 'src/app/shared/model/response/IResBulkSearch';
import { HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-bulk-search',
  templateUrl: './bulk-search.component.html',
  styleUrls: ['./bulk-search.component.scss']
})
export class BulkSearchComponent implements AfterViewInit, OnDestroy, OnInit  {
  @ViewChild('inputFile') inputFile: ElementRef;
  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  selectedFiles?: FileList;
  currentFile?: File;
  progress = 0;
  message = '';

  filePlaceholder = ''

  fileInfos?: Observable<any>;

  bulkSearchData: IResBulkSearch[] = [];

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg: string;

  constructor(
    private searchService: SearchService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.dtOptions = {      
      columns: [        
        { "searchable": false, orderable: false },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": false, orderable: false }
      ],
      order: [[ 3, 'asc' ]],
      responsive: true      
    }; 

    
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  selectFile(event: any): void {
    this.selectedFiles = event.target.files;
    console.log(this.selectedFiles)
    if (this.selectedFiles) {
      const file = this.selectedFiles.item(0);
      if (file) {
        this.filePlaceholder = file.name
      }
    }
  }

  upload(): void {
    this.btnLoading = true;
    this.progress = 0;

    this.bulkSearchData = []
    
    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);

      if (file) {
        this.currentFile = file;
        const cacheKey = `${file.name}|${this.tokenStorageService.getUserGUID()}|${moment(new Date()).format("YYYY-MM-DD HH:mm")}`;        
        this.searchService.bulkSearch(this.currentFile, cacheKey).subscribe(
          event => {
            console.log(event, 'bulksearch')
            // if (data.length > 0) {
            //   console.log(data.length, 'data length')
            //   data.forEach(d => d.Flag = JSON.parse(d.Flag)[0])
            //   this.bulkSearchData = data;
            //   this.toastr.success("Success");
            //   this.rerender()
            //   console.log('bulkSearch', data);
            // } else {
            //   console.log(data, 'data')
            //   this.toastr.info("No record found")
            // }


          //   if (event.type === HttpEventType.UploadProgress) {
          //     this.progress = Math.round(100 * event.loaded / event.total);
          // }
          // else if (event.type === HttpEventType.Response) {
          //     this.message = event.body.toString();
          // }

          if (event.type === HttpEventType.Response) {
           if (Array.isArray(event.body)) {
             console.log(' is Array', event.body)
             const data= event.body;
             data.forEach(d => d.Flag = JSON.parse(d.Flag)[0])
             this.bulkSearchData = data;
             this.toastr.success("Success");
             this.rerender()
           } else {
            this.toastr.info("No file found")
           }
          }
          },
          err => {
            this.btnLoading = false;
            this.toastr.error("No Data");
          }
        )
      }
      this.btnLoading = false;
      this.selectedFiles = undefined;
      this.inputFile.nativeElement.value = '';
      this.filePlaceholder = "Choose file"
    }
  }

}
