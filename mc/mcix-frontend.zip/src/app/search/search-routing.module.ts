import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SimpleSearchComponent } from './simple-search/simple-search.component';
import { CreditReportComponent } from './credit-report/credit-report.component';
import { BulkSearchComponent } from './bulk-search/bulk-search.component';
import { AuthGuard } from '../auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/search/simple', pathMatch: 'full' },
  { path: 'simple', component:  SimpleSearchComponent, canActivate: [AuthGuard], data: {menuId: '23'} },
  { path: 'credit-report/:id', component:  CreditReportComponent, canActivate: [AuthGuard], data: {menuId: '23'} },
  { path: 'bulk', component:  BulkSearchComponent, canActivate: [AuthGuard], data: {menuId: '24'} }      
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SearchRoutingModule { }
