
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './shared/component/home/home.component';
import { ProfileComponent } from './shared/component/profile/profile.component';
import { ResetPasswordComponent } from './shared/component/reset-password/reset-password.component';
import { NotificationDetailsComponent } from './shared/component/notification-details/notification-details.component';
import { GenerateKeysComponent } from './shared/component/generate-keys/generate-keys.component';
import { TestComponent } from './shared/component/test/test.component';


const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  // { path: '', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'test1', component:  TestComponent },
  { path: 'home', component:  HomeComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'reset-password', component: ResetPasswordComponent },
  { path: 'notification-details/:type', component: NotificationDetailsComponent },
  { path: 'generate-keys', component: GenerateKeysComponent },
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) },
  { path: 'search', loadChildren: () => import('./search/search.module').then(m => m.SearchModule) },
  { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule) },
  { path: 'report', loadChildren: () => import('./report/report.module').then(m => m.ReportModule) },
  { path: 'user', loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
  { path: 'upload', loadChildren: () => import('./upload/upload.module').then(m => m.UploadModule) },
  { path: 'company-profile', loadChildren: () => import('./company-profile/company-profile.module').then(m => m.CompanyProfileModule) },
  { path: 'account', loadChildren: () => import('./account/account.module').then(m => m.AccountModule) },
  { path: 'mfi', loadChildren: () => import('./mfi/mfi.module').then(m => m.MfiModule) },
  { path: '**', loadChildren: () => import('./not-found/not-found.module').then(m => m.NotFoundModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
