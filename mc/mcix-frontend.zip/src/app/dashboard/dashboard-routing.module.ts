import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/overlap/summary', pathMatch: 'full' },
  { path: 'overlap', loadChildren: () => import('./overlap/overlap.module').then(m => m.OverlapModule) },
  { path: 'upload-stats', loadChildren: () => import('./upload-stats/upload-stats.module').then(m => m.UploadStatsModule) },
  { path: 'search-stats', loadChildren: () => import('./search-stats/search-stats.module').then(m => m.SearchStatsModule) },
  { path: 'penetration', loadChildren: () => import('./penetration/penetration.module').then(m => m.PenetrationModule) },
  { path: 'audit', loadChildren: () => import('./audit/audit.module').then(m => m.AuditModule) },
  { path: 'publication', loadChildren: () => import('./publication/publication.module').then(m => m.PublicationModule) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
