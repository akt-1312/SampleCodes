import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UploadActiveComponent } from './upload-active/upload-active.component';
import { UploadWriteOffComponent } from './upload-write-off/upload-write-off.component';
import { UploadProblematicComponent } from './upload-problematic/upload-problematic.component';
import { AuthGuard } from 'src/app/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/upload-stats/active', pathMatch: 'full' },
  { path: 'active', component:  UploadActiveComponent, canActivate: [AuthGuard], data: {menuId: '28'} },
  { path: 'write-off', component:  UploadWriteOffComponent, canActivate: [AuthGuard], data: {menuId: '29'} },
  { path: 'problematic', component:  UploadProblematicComponent, canActivate: [AuthGuard], data: {menuId: '30'} } 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UploadStatsRoutingModule { }
