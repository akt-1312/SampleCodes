import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { DashboardService } from 'src/app/shared/service/dashboard.service';

import { IMonthLabel } from 'src/app/shared/model/IMonthLabel';
import { IUpload } from 'src/app/shared/model/IUpload';

@Component({
  selector: 'app-upload-write-off',
  templateUrl: './upload-write-off.component.html',
  styleUrls: ['./upload-write-off.component.scss']
})
export class UploadWriteOffComponent implements OnInit {

  writeOffClientMonthlyUploadData = [[]]

  // Initial Data
  initialMonths: IMonthLabel = {
    monthOne: '',
    monthTwo: '',
    monthThree: '',
    monthFour: '',
    monthFive: '',
    monthSix: '',
  }

  initialData: IUpload = {
    institutionData: [],    
    monthOneData: [],
    monthTwoData: [],
    monthThreeData: [],
    monthFourData: [],
    monthFiveData: [],
    monthSixData: []
  }
  totalItems = 0

  itemsPerPage = 10
  currentPage  = 1

  barChartOptions: ChartOptions = {responsive: true};
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'horizontalBar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [];

  errorMsg: string;
  loading = false;

  constructor(
    private dashboardService: DashboardService
  ) { }

  ngOnInit(): void {
    this.getWriteOffClientMonthlyUpload()
  }

  getWriteOffClientMonthlyUpload() {
    this.loading = true;
    this.dashboardService.getWriteOffClientMonthlyUpload().subscribe(data=> {
      if (data.length) {
        this.writeOffClientMonthlyUploadData = data;
        this.getInitialData()
        this.loading = false;
      }
    },
    err => {
      console.log(err, 'error');
      this.loading = false;
    })
  }

  getInitialData() {
    const mainData = this.writeOffClientMonthlyUploadData
    let mainDataWithoutHeader = [[]]
    console.log(mainData, 'mainData')
    const institutionData: string[] = []   
    const monthOneData: number[] = []
    const monthTwoData: number[] = []
    const monthThreeData: number[] = []
    const monthFourData: number[] = []
    const monthFiveData: number[] = []
    const monthSixData: number[] = []   

     // remove header row
    if (mainData.length > 0 && mainData[0][0] === 'Institution') {
      this.totalItems = mainData.length - 1;
    } else {
      this.totalItems = mainData.length;
    }

    if (mainData[0] && mainData[0].length === 7) {     
      this.initialMonths = {
        monthOne: mainData[0][1],
        monthTwo: mainData[0][2],
        monthThree: mainData[0][3],
        monthFour: mainData[0][4],
        monthFive: mainData[0][5],
        monthSix: mainData[0][6],
      }    

      // remove first item (header) - we don't need to render
      if (mainData.length > 0 && mainData[0][0] === 'Institution') {
        mainDataWithoutHeader = mainData.filter(item => item[0] !== 'Institution')
      }
      mainDataWithoutHeader.forEach(item => {
        institutionData.push(item[0])        
        monthOneData.push(parseInt(item[1])|| 0)
        monthTwoData.push(parseInt(item[2])|| 0)
        monthThreeData.push(parseInt(item[3])|| 0)
        monthFourData.push(parseInt(item[4])|| 0)
        monthFiveData.push(parseInt(item[5])|| 0)
        monthSixData.push(parseInt(item[6])|| 0)
      })    
    }

    this.initialData = {
      institutionData,
      monthOneData,
      monthTwoData,
      monthThreeData,
      monthFourData,
      monthFiveData,
      monthSixData
    }

    this.getPaginationData(this.currentPage)
  }

  getPaginationData(page: number) {
    let start = (page - 1) * this.itemsPerPage 
    let end = this.totalItems

    if (this.itemsPerPage < this.totalItems) {
      end = this.itemsPerPage * page
      if (end > this.totalItems) {
        end = this.totalItems
      }
    }

    this.barChartLabels = this.initialData.institutionData.slice(start, end);
    this.barChartData = [
      { data: this.initialData.monthOneData.slice(start, end), label: this.initialMonths.monthOne },
      { data: this.initialData.monthTwoData.slice(start, end), label: this.initialMonths.monthTwo },
      { data: this.initialData.monthThreeData.slice(start, end), label: this.initialMonths.monthThree },
      { data: this.initialData.monthFourData.slice(start, end), label: this.initialMonths.monthFour },
      { data: this.initialData.monthFiveData.slice(start, end), label: this.initialMonths.monthFive },
      { data: this.initialData.monthSixData.slice(start, end), label: this.initialMonths.monthSix },
    ]
    
  }

  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.getPaginationData(event.page)
  }

}
