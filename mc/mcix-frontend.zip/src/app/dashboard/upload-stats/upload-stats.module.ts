import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { DataTablesModule } from "angular-datatables";
import { ShareModule } from 'src/app/shared/module/share/share.module';
import { TooltipModule } from 'ngx-bootstrap/tooltip';

import { UploadStatsRoutingModule } from './upload-stats-routing.module';
import { UploadActiveComponent } from './upload-active/upload-active.component';
import { UploadWriteOffComponent } from './upload-write-off/upload-write-off.component';
import { UploadProblematicComponent } from './upload-problematic/upload-problematic.component';


@NgModule({
  declarations: [
    UploadActiveComponent,
    UploadWriteOffComponent,
    UploadProblematicComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ChartsModule,
    UploadStatsRoutingModule,
    ShareModule,
    DataTablesModule,
    PaginationModule.forRoot(),
    TooltipModule.forRoot(),
  ]
})
export class UploadStatsModule { }
