import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadActiveComponent } from './upload-active.component';

describe('UploadActiveComponent', () => {
  let component: UploadActiveComponent;
  let fixture: ComponentFixture<UploadActiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploadActiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadActiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
