import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadProblematicComponent } from './upload-problematic.component';

describe('UploadProblematicComponent', () => {
  let component: UploadProblematicComponent;
  let fixture: ComponentFixture<UploadProblematicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploadProblematicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadProblematicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
