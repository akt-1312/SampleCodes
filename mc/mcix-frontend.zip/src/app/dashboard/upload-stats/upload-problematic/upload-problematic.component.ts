import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';

import { CompanyProfileService } from 'src/app/shared/service/company-profile.service';

import { IResCompanyStatsDetail } from 'src/app/shared/model/response/IResCompanyStatsDetail';

@Component({
  selector: 'app-upload-problematic',
  templateUrl: './upload-problematic.component.html',
  styleUrls: ['./upload-problematic.component.scss']
})
export class UploadProblematicComponent implements OnInit {

  loading = false;
  errorMsg = '';  

  dtOptions: DataTables.Settings = {};

  profileDetailData: IResCompanyStatsDetail[] = []

  constructor(
    private companyProfileService: CompanyProfileService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.dtOptions = {
      responsive: true
    };

    this.getCompanyProfileDetails()
  }

  getCompanyProfileDetails(): void {   

    this.loading = true;
    const pLGUID = '00000000-0000-0000-0000-000000000000';
    const pReportingDate = moment().subtract(1, 'months').format("YYYYMM"); // current month -1
    const pShowOnlyBadFlag = 'true';

    this.companyProfileService.getCompanyProfileDetails(
      pLGUID,
      pReportingDate,
      pShowOnlyBadFlag
    ).subscribe(data => {
      this.profileDetailData = data;
      this.loading = false;
    },
    err => {
      this.loading = false;
      this.errorMsg = err;
      this.toastr.error("Error.")
    })
  }

}
