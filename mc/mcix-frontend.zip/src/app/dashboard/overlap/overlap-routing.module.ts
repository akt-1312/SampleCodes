import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OverlapSummaryComponent } from './overlap-summary/overlap-summary.component';
import { OverlapDetailsComponent } from './overlap-details/overlap-details.component';
import { OverlapTrendComponent } from './overlap-trend/overlap-trend.component';
import { AuthGuard } from 'src/app/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/overlap/summary', pathMatch: 'full' },
  { path: 'summary', component:  OverlapSummaryComponent, canActivate: [AuthGuard], data: {menuId: '25'} },
  { path: 'details', component:  OverlapDetailsComponent, canActivate: [AuthGuard], data: {menuId: '26'} },
  { path: 'trend', component:  OverlapTrendComponent, canActivate: [AuthGuard], data: {menuId: '27'} } 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OverlapRoutingModule { }
