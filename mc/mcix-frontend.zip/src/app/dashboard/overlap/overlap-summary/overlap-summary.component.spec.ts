import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlapSummaryComponent } from './overlap-summary.component';

describe('OverlapSummaryComponent', () => {
  let component: OverlapSummaryComponent;
  let fixture: ComponentFixture<OverlapSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverlapSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlapSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
