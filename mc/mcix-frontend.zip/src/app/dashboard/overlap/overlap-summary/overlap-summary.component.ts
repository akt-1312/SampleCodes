import { Component, OnDestroy, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { DataTableDirective } from 'angular-datatables';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { AppService } from 'src/app/shared/service/app.service';
import { DashboardService } from 'src/app/shared/service/dashboard.service';
import { ToastrService } from 'ngx-toastr';

import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { Observable, of, Subject  } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';
import { getLastMonths } from 'src/app/shared/helper/months';
import { exportToCsv } from 'src/app/shared/helper/exportCsv';

@Component({
  selector: 'app-overlap-summary',
  templateUrl: './overlap-summary.component.html',
  styleUrls: ['./overlap-summary.component.scss']
})
export class OverlapSummaryComponent implements OnDestroy, OnInit, AfterViewInit {  
  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  loadingDivisions = false;
  divisions$: Observable<IResCodeName[]>;

  loadingTownships = false;
  townships$: Observable<IResCodeName[]>;

  
  months: IResCodeName[];

  errorMsg: string;

  overlap: any = [];
  overlapHeader: any = [];
  overlapBody: any = []
  pCategory = "summary"
  pCategorySummary = "summary"
  pCategoryPercentage = "percentage"
  fileNameOverlapSummary = "_Export Overlap Summary.csv"
  fileNameOverlapSummaryPercentage = "_Export Overlap Summary Percentage.csv"
  fileName = ""
  pLoanCount="0"

  searchForm: FormGroup = new FormGroup({
    pDivisionCode: new FormControl(),
    pTownshipCode: new FormControl(),
    pReportingYYYYMM: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;

  isSwitchChecked = false;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private tokenStorageService: TokenStorageService,
    private dashboardService: DashboardService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.dtOptions = {
      paging:   false,
      ordering: false,
      info:     false,
      searching: false,
      responsive: true
    }

    this.fileName = this.fileNameOverlapSummary

    this.searchForm = this.formBuilder.group({
      pDivisionCode: [null, [Validators.required]],
      pTownshipCode: [null, [Validators.required]],
      pReportingYYYYMM: [null, [Validators.required]]
    });

    this.getDivisions()

    this.months = getLastMonths(6);    
  } 

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
    // Destroy the table first
    dtInstance.destroy();
    // Call the dtTrigger to rerender again
    this.dtTrigger.next();
  });}

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }  
  
  get f() { return this.searchForm.controls; }  

  getDivisions(): void {
    this.loadingDivisions = true;      
    this.divisions$ = this.appService
                .getDivisions(
                  this.tokenStorageService.getAccountGUID(), 
                  this.tokenStorageService.getUserGUID()
                )
                .pipe(   
                  map(response => response.map(item => {
                    return {...item, Name: `${item.Code} - ${item.Name}`}
                  })),
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingDivisions=false)
                )

  }
  
  onChangeDivisions(): void {
    console.log('change', this.f.pDivisionCode.value)
    this.getTownships();
  }

  getTownships(): void {
    this.loadingTownships = true;
    this.townships$ = this.appService
                        .getTownships(
                          this.f.pDivisionCode.value,
                          this.tokenStorageService.getAccountGUID(), 
                          this.tokenStorageService.getUserGUID()
                        )
                        .pipe(
                          map(response => response.map(item => {
                            return {...item, Name: `${item.Code} - ${item.Name}`}
                          })),
                          catchError(error => {
                            this.errorMsg = error.message;
                            return of([]);
                          }),
                          finalize(()=>this.loadingTownships=false)
                        )
    
  }
  
  checkSwitchValue(event: any) {    
    this.pCategory = event ? this.pCategoryPercentage : this.pCategorySummary;
    this.fileName  = event ? this.fileNameOverlapSummaryPercentage : this.fileNameOverlapSummary;
    this.loading = true;
    this.getOverlapBorrowers();
  }

  onSubmit() {    

    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.getOverlapBorrowers()
  }

  getOverlapBorrowers() {
    this.dashboardService.getOverlapBorrowers(
      this.f.pDivisionCode.value,
      this.f.pTownshipCode.value,
      this.pCategory,
      this.f.pReportingYYYYMM.value,
      this.pLoanCount
    ).subscribe(
      data => {
        
        this.btnLoading = false;
        this.loading = false;

        if ( data[0][0] == "NO DATA" ) {
          this.toastr.error(data[0][0]);
        } else {

          console.log(data,' data');
          // data.map(item )

          const arr = this.transpose(data);
          console.log(arr, 'arr')

          const zeroFillArr = arr.map(row => row.map(element => element === '' ? '0' : element))
          console.log(zeroFillArr, 'zeroFillArr')

          if (this.pCategory === this.pCategoryPercentage) {
            

            const percentageArr = zeroFillArr.map((row, index) => {
              if (index > 0) {
                  return row.map((e:any) => {
                    if (!isNaN(e)) {
                      e = e * 100
                      e = e+'%'
                      console.log(e)
                      return e
                    } else {
                      return e
                    }
                  })
              } else {
                return row
              }
            })

            this.overlap = percentageArr

          } else {
            this.overlap = zeroFillArr
          }

          
          console.log(this.overlap, 'overlap')
          
          this.overlapHeader = this.overlap[0]
          this.overlapBody = [...this.overlap.slice(1)]
          

          console.log(this.overlapHeader, this.overlapBody)    
          
          

          // this.dtTrigger.next();
          this.rerender();
          
        }
      },
      err => {
        this.btnLoading = false;
        this.loading = false;
        console.log('overlap', err);
      }
    )
  }

  transpose(matrix) {
    return matrix.reduce((prev, next) => next.map((item, i) =>
      (prev[i] || []).concat(next[i])
    ), []);
  }

  downloadCsv() {
    exportToCsv(this.fileName, this.overlap)
  }  

}



