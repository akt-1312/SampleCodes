import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlapTrendComponent } from './overlap-trend.component';

describe('OverlapTrendComponent', () => {
  let component: OverlapTrendComponent;
  let fixture: ComponentFixture<OverlapTrendComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverlapTrendComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlapTrendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
