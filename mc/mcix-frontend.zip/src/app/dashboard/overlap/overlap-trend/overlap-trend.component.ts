import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { ToastrService } from 'ngx-toastr';

import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { AppService } from 'src/app/shared/service/app.service';
import { DashboardService } from 'src/app/shared/service/dashboard.service';
import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { Observable, of } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';

import { IMonthLabel } from 'src/app/shared/model/IMonthLabel';
import { IMonthData } from 'src/app/shared/model/IMonthData';

@Component({
  selector: 'app-overlap-trend',
  templateUrl: './overlap-trend.component.html',
  styleUrls: ['./overlap-trend.component.scss']
})
export class OverlapTrendComponent implements OnInit {

  overlapBorrowersTrendData = [[]]
  

  // Initial Data
  initialMonths: IMonthLabel = {
    monthOne: '',
    monthTwo: '',
    monthThree: '',
    monthFour: '',
    monthFive: '',
    monthSix: '',
  }
  initialData: IMonthData = {
    institutionData: [],
    loanCountData: [],
    institutionLCountData: [],
    monthOneData: [],
    monthTwoData: [],
    monthThreeData: [],
    monthFourData: [],
    monthFiveData: [],
    monthSixData: []
  }
  totalItems = 0

  // Current Data
  filterMonths: IMonthLabel = {
    monthOne: '',
    monthTwo: '',
    monthThree: '',
    monthFour: '',
    monthFive: '',
    monthSix: '',
  }
  currentData: IMonthData = {
    institutionData: [],
    loanCountData: [],
    institutionLCountData: [],
    monthOneData: [],
    monthTwoData: [],
    monthThreeData: [],
    monthFourData: [],
    monthFiveData: [],
    monthSixData: []
  }

  uniqueInstitutionData: string[] = []
  uniqueLoanCountData: string[] = []


  itemsPerPage = 10
  currentPage  = 1

  barChartOptions: ChartOptions = {responsive: true};
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'horizontalBar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [];

  selectedInstitute = []
  selectedLoanCount = []

  loadingDivisions = false;
  divisions$: Observable<IResCodeName[]>;

  loadingTownships = false;
  townships$: Observable<IResCodeName[]>;

  errorMsg: string;

  loading = false;
  btnLoading = false;
  submitted = false;

  searchForm: FormGroup = new FormGroup({
    pDivisionCode: new FormControl(),
    pTownshipCode: new FormControl()
  });

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private dashboardService: DashboardService,
    private tokenStorageService: TokenStorageService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.searchForm = this.formBuilder.group({
      pDivisionCode: [null, [Validators.required]],
      pTownshipCode: [null, [Validators.required]]
    });

    

    this.getDivisions()
  }

  get f() { return this.searchForm.controls; }  

  getDivisions(): void {
    this.loadingDivisions = true;      
    this.divisions$ = this.appService
                .getDivisions(
                  this.tokenStorageService.getAccountGUID(), 
                  this.tokenStorageService.getUserGUID()
                )
                .pipe(   
                  map(response => response.map(item => {
                    return {...item, Name: `${item.Code} - ${item.Name}`}
                  })),
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingDivisions=false)
                )

  }

  onChangeDivisions(): void {
    console.log('change', this.f.pDivisionCode.value)
    this.getTownships();
  }

  getTownships(): void {
    this.loadingTownships = true;
    this.townships$ = this.appService
                        .getTownships(
                          this.f.pDivisionCode.value,
                          this.tokenStorageService.getAccountGUID(), 
                          this.tokenStorageService.getUserGUID()
                        )
                        .pipe(
                          map(response => response.map(item => {
                            return {...item, Name: `${item.Code} - ${item.Name}`}
                          })),
                          catchError(error => {
                            this.errorMsg = error.message;
                            return of([]);
                          }),
                          finalize(()=>this.loadingTownships=false)
                        )
    
  }

  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.dashboardService.getOverlapBorrowersTrend(
      this.f.pDivisionCode.value,
      this.f.pTownshipCode.value,
    ).subscribe(data=> {
      this.btnLoading = false;
      if (data.length === 1 && data[0][0] === 'NO DATA') {
        this.toastr.error('No data');
      } else {
        this.overlapBorrowersTrendData = data;
        this.getInitialData();        
      }
    },
    err => {
      console.log(err, 'error');      
      this.btnLoading = false;
    })
  }


  getInitialData() {
    const mainData = this.overlapBorrowersTrendData
    let mainDataWithoutHeader = [[]]
    console.log(mainData, 'mainData')
    const institutionData: string[] = []
    const loanCountData: string[] = []
    const institutionLCountData: string[] = []
    const monthOneData: number[] = []
    const monthTwoData: number[] = []
    const monthThreeData: number[] = []
    const monthFourData: number[] = []
    const monthFiveData: number[] = []
    const monthSixData: number[] = []   

    // remove header row
    if (mainData.length > 0 && mainData[0][0] === 'Institute') {
      this.totalItems = mainData.length - 1;
    } else {
      this.totalItems = mainData.length;
    }
    

    if (mainData[0] && mainData[0].length === 9) {     
      

      this.initialMonths = {
        monthOne: mainData[0][3],
        monthTwo: mainData[0][4],
        monthThree: mainData[0][5],
        monthFour: mainData[0][6],
        monthFive: mainData[0][7],
        monthSix: mainData[0][8],
      }     

      

      // remove first item (header) - we don't need to render
      if (mainData.length > 0 && mainData[0][0] === 'Institute') {
        mainDataWithoutHeader = mainData.filter(item => item[0] !== 'Institute')
      }
      mainDataWithoutHeader.forEach(item => {
        institutionData.push(item[0])
        loanCountData.push(item[1])
        institutionLCountData.push(item[2])
        monthOneData.push(parseInt(item[3])|| 0)
        monthTwoData.push(parseInt(item[4])|| 0)
        monthThreeData.push(parseInt(item[5])|| 0)
        monthFourData.push(parseInt(item[6])|| 0)
        monthFiveData.push(parseInt(item[7])|| 0)
        monthSixData.push(parseInt(item[8])|| 0)
      })    

    }
    
    this.uniqueInstitutionData = institutionData.filter((v, i, a) => a.indexOf(v) === i);
    this.uniqueLoanCountData = loanCountData.filter((v, i, a) => a.indexOf(v) === i);
    
    this.initialData = {
      institutionData,
      loanCountData,
      institutionLCountData,
      monthOneData,
      monthTwoData,
      monthThreeData,
      monthFourData,
      monthFiveData,
      monthSixData
    }

    this.currentData = {
      institutionData,
      loanCountData,
      institutionLCountData,
      monthOneData,
      monthTwoData,
      monthThreeData,
      monthFourData,
      monthFiveData,
      monthSixData
    }
    this.getPaginationData(this.currentPage)
  }

  getFilterData(data: any) {
    const mainData = data
    const institutionData: string[] = []
    const loanCountData: string[] = []
    const institutionLCountData: string[] = []
    const monthOneData: number[] = []
    const monthTwoData: number[] = []
    const monthThreeData: number[] = []
    const monthFourData: number[] = []
    const monthFiveData: number[] = []
    const monthSixData: number[] = []   

    this.totalItems = mainData.length;    

    mainData.forEach(item => {
      institutionData.push(item[0])
      loanCountData.push(item[1])
      institutionLCountData.push(item[2])
      monthOneData.push(parseInt(item[3])|| 0)
      monthTwoData.push(parseInt(item[4])|| 0)
      monthThreeData.push(parseInt(item[5])|| 0)
      monthFourData.push(parseInt(item[6])|| 0)
      monthFiveData.push(parseInt(item[7])|| 0)
      monthSixData.push(parseInt(item[8])|| 0)
    })  
    
    this.currentData = {
      institutionData,
      loanCountData,
      institutionLCountData,
      monthOneData,
      monthTwoData,
      monthThreeData,
      monthFourData,
      monthFiveData,
      monthSixData
    }

    
    this.getPaginationData(this.currentPage)
  }

  

  onSelectData(name: string) {
    console.log('getChartData', this.selectedInstitute, name)
    
    if (name === 'institute') {
      this.selectedLoanCount = []
    }

    let selectedInstitute: string[] = Array.from(this.selectedInstitute).map(option => option) 
    let selectedLoanCount = Array.from(this.selectedLoanCount).map(option => option)

    // console.log(selectedInstitute, 'selectedInstitute')
    // console.log(selectedLoanCount, 'selectedLoanCount')

    let queryData: any= [];
    let selectedData: any= [];
    const loanCountData: string[] = []

    if (selectedInstitute.length > 0 ) {
      selectedInstitute.forEach(institute => {
        this.overlapBorrowersTrendData.forEach(arr => {
          if ( arr[0] === institute ) {
            queryData.push(arr)
          }
        })

        queryData.forEach(item => loanCountData.push(item[1]))
        this.uniqueLoanCountData = loanCountData.filter((v, i, a) => a.indexOf(v) === i);


        if (selectedLoanCount.length > 0) {
          selectedLoanCount.forEach(loanCount => {
            console.log(queryData, loanCount)
            queryData.forEach(arr => {
              if (arr[1] === loanCount) {
                selectedData.push(arr)
              }
            })
          })
        } else {
          selectedData = queryData
        }
        
      })      
    } else {
      if (selectedLoanCount.length > 0  ) {
        selectedLoanCount.forEach(loanCount => {
          this.overlapBorrowersTrendData.forEach(arr => {
            if ( arr[1] === loanCount ) {
              queryData.push(arr)
            }
          })
        })   
        selectedData = queryData   
      } 
    }

    
    selectedData = selectedData.filter((v, i, a) => a.indexOf(v) === i);
    if (selectedData.length > 0) {
      this.getFilterData(selectedData)
    } else {
      console.log('getInitialData')
      this.getInitialData()
    }

    
  }

  getPaginationData(page: number) {
    let start = (page - 1) * this.itemsPerPage 
    let end = this.totalItems

    if (this.itemsPerPage < this.totalItems) {
      end = this.itemsPerPage * page
      if (end > this.totalItems) {
        end = this.totalItems
      }
    }

    this.barChartLabels = this.currentData.institutionLCountData.slice(start, end);
    this.barChartData = [
      { data: this.currentData.monthOneData.slice(start, end), label: this.initialMonths.monthOne },
      { data: this.currentData.monthTwoData.slice(start, end), label: this.initialMonths.monthTwo },
      { data: this.currentData.monthThreeData.slice(start, end), label: this.initialMonths.monthThree },
      { data: this.currentData.monthFourData.slice(start, end), label: this.initialMonths.monthFour },
      { data: this.currentData.monthFiveData.slice(start, end), label: this.initialMonths.monthFive },
      { data: this.currentData.monthSixData.slice(start, end), label: this.initialMonths.monthSix },
    ]
    
  }

  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.getPaginationData(event.page)
  }

}
