import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlapDetailsComponent } from './overlap-details.component';

describe('OverlapDetailsComponent', () => {
  let component: OverlapDetailsComponent;
  let fixture: ComponentFixture<OverlapDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverlapDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlapDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
