import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { AppService } from 'src/app/shared/service/app.service';
import { DashboardService } from 'src/app/shared/service/dashboard.service';
import { ToastrService } from 'ngx-toastr';

import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { IResOverlapLoanCount } from 'src/app/shared/model/response/IResOverlapLoanCount';
import { Observable, of } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';
import { getLastMonths } from 'src/app/shared/helper/months';
import { exportToCsv } from 'src/app/shared/helper/exportCsv';

@Component({
  selector: 'app-overlap-details',
  templateUrl: './overlap-details.component.html',
  styleUrls: ['./overlap-details.component.scss']
})
export class OverlapDetailsComponent implements OnInit {

  loadingDivisions = false;
  divisions$: Observable<IResCodeName[]>;

  loadingTownships = false;
  townships$: Observable<IResCodeName[]>;

  months: IResCodeName[];

  errorMsg: string;

  
  overlap: IResOverlapLoanCount[] = []
  overlapDetail: [] = []
  pCategory = "detail"

  searchForm: FormGroup = new FormGroup({
    pDivisionCode: new FormControl(),
    pTownshipCode: new FormControl(),
    pReportingYYYYMM: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private tokenStorageService: TokenStorageService,
    private dashboardService: DashboardService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.searchForm = this.formBuilder.group({
      pDivisionCode: [null, [Validators.required]],
      pTownshipCode: [null, [Validators.required]],
      pReportingYYYYMM: [null, [Validators.required]]
    });

    this.getDivisions()
    this.months = getLastMonths(6);
  }

  get f() { return this.searchForm.controls; }  

  getDivisions(): void {
    this.loadingDivisions = true;      
    this.divisions$ = this.appService
                .getDivisions(
                  this.tokenStorageService.getAccountGUID(), 
                  this.tokenStorageService.getUserGUID()
                )
                .pipe(   
                  map(response => response.map(item => {
                    return {...item, Name: `${item.Code} - ${item.Name}`}
                  })),
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingDivisions=false)
                )

  }

  onChangeDivisions(): void {
    console.log('change', this.f.pDivisionCode.value)
    this.getTownships();
  }

  getTownships(): void {
    this.loadingTownships = true;
    this.townships$ = this.appService
                        .getTownships(
                          this.f.pDivisionCode.value,
                          this.tokenStorageService.getAccountGUID(), 
                          this.tokenStorageService.getUserGUID()
                        )
                        .pipe(
                          map(response => response.map(item => {
                            return {...item, Name: `${item.Code} - ${item.Name}`}
                          })),
                          catchError(error => {
                            this.errorMsg = error.message;
                            return of([]);
                          }),
                          finalize(()=>this.loadingTownships=false)
                        )
  }

  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.dashboardService.getOverlapLoanCount(
      this.f.pDivisionCode.value,
      this.f.pTownshipCode.value,
      this.f.pReportingYYYYMM.value
    ).subscribe(
      data => {
        
        this.btnLoading = false;

        if (data.length) {
          console.log('true')
          this.overlap = data
        } else {
          console.log('false')
          this.toastr.error("No rows found");
        }
      },
      err => {
        this.btnLoading = false;
        console.log('overlap', err);
      }
    )
  }

  getOverlapBorrowersDetail(event: any, pLoanCount: string) {
    event.preventDefault();
    this.dashboardService.getOverlapBorrowers(
      this.f.pDivisionCode.value,
      this.f.pTownshipCode.value,
      this.pCategory,
      this.f.pReportingYYYYMM.value,
      pLoanCount
    ).subscribe(
      data => {
        
        this.btnLoading = false;
        this.loading = false;

        if ( data[0][0] == "NO DATA" ) {
          this.toastr.error(data[0][0]);
        } else {
          console.log(data)
          this.overlapDetail = data;

        }
      },
      err => {
        this.btnLoading = false;
        this.loading = false;
        console.log('overlap', err);
      }
    )
  }

  downloadCsv() {
    exportToCsv('Overlap_Details.csv', this.overlapDetail)
  }

}
