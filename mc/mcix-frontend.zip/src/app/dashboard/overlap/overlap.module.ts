import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { NgSelectModule } from '@ng-select/ng-select';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { ShareModule } from 'src/app/shared/module/share/share.module';
import { OverlapRoutingModule } from './overlap-routing.module';
import { DataTablesModule } from "angular-datatables";
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { OverlapSummaryComponent } from './overlap-summary/overlap-summary.component';
import { OverlapDetailsComponent } from './overlap-details/overlap-details.component';
import { OverlapTrendComponent } from './overlap-trend/overlap-trend.component';



@NgModule({
  declarations: [
    OverlapSummaryComponent,
    OverlapDetailsComponent,
    OverlapTrendComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OverlapRoutingModule,
    NgSelectModule,
    ChartsModule,
    ShareModule,
    DataTablesModule,
    PaginationModule.forRoot(),
    TooltipModule.forRoot()
  ]
})
export class OverlapModule { }
