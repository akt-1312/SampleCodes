import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { OverlapModule } from './overlap/overlap.module';
import { UploadStatsModule } from './upload-stats/upload-stats.module';
import { SearchStatsModule } from './search-stats/search-stats.module';
import { PenetrationModule } from './penetration/penetration.module';
import { AuditModule } from './audit/audit.module';
import { PublicationModule } from './publication/publication.module';



@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    OverlapModule,
    UploadStatsModule,
    SearchStatsModule,
    PenetrationModule,
    AuditModule,
    PublicationModule
  ]
})
export class DashboardModule { }
