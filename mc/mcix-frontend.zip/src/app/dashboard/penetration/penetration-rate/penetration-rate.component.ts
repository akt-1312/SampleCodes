import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ToastrService } from 'ngx-toastr';
import { AppService } from 'src/app/shared/service/app.service';
import { DashboardService } from 'src/app/shared/service/dashboard.service';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';

import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { IResPenetrationRate } from 'src/app/shared/model/response/IResPenetrationRate';
import { Observable, of } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';
import { getLastMonths } from 'src/app/shared/helper/months';
import { groupBy } from 'src/app/shared/helper/groupby';

@Component({
  selector: 'app-penetration-rate',
  templateUrl: './penetration-rate.component.html',
  styleUrls: ['./penetration-rate.component.scss']
})
export class PenetrationRateComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  loadingDivisions = false;
  divisions$: Observable<IResCodeName[]>;

  loadingTownships = false;
  townships$: Observable<IResCodeName[]>;

  
  months: IResCodeName[];

  errorMsg: string;  

  dataPenetrationRate: IResPenetrationRate[] = [];

  searchForm: FormGroup = new FormGroup({
    pDivisionCode: new FormControl(),
    pReportingYYYYMM_From: new FormControl(),
    pReportingYYYYMM_To: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;

  barChartOptions: ChartOptions = {responsive: true, scales: {yAxes: [{ticks: {beginAtZero: true}}]}};
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'line';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [];  
  barChartColors: Color[] = [
    { borderColor: '#4e73df',  backgroundColor: 'rgba(255,255,255,0.1)' },
    { borderColor: '#1cc88a',  backgroundColor: 'rgba(255,255,255,0.1)' }
  ]

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private tokenStorageService: TokenStorageService,
    private dashboardService: DashboardService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.searchForm = this.formBuilder.group({
      pDivisionCode: [null, [Validators.required]],
      pReportingYYYYMM_From: [null, [Validators.required]],
      pReportingYYYYMM_To: [null, [Validators.required]]
    });

    this.dtOptions = {      
      responsive: true
    }; 

    this.getDivisions()
    this.months = getLastMonths(6);



    // const test = {"Bogale":[{"Division":"Ayeyarwady","Township":"Bogale","NoOfBorrowers":15,"NoOfHouseholds":75987,"AdjustedPenetrationRate":0.000197402187216234,"Month":"202107"},{"Division":"Ayeyarwady","Township":"Bogale","NoOfBorrowers":26,"NoOfHouseholds":75987,"AdjustedPenetrationRate":0.000342163791174806,"Month":"202108"},{"Division":"Ayeyarwady","Township":"Bogale","NoOfBorrowers":8,"NoOfHouseholds":75987,"AdjustedPenetrationRate":0.000105281166515325,"Month":"202109"}],"Danubyu":[{"Division":"Ayeyarwady","Township":"Danubyu","NoOfBorrowers":2,"NoOfHouseholds":44797,"AdjustedPenetrationRate":0.0000446458468201,"Month":"202107"},{"Division":"Ayeyarwady","Township":"Danubyu","NoOfBorrowers":1,"NoOfHouseholds":44797,"AdjustedPenetrationRate":0.00002232292341005,"Month":"202108"},{"Division":"Ayeyarwady","Township":"Danubyu","NoOfBorrowers":0,"NoOfHouseholds":44797,"AdjustedPenetrationRate":0,"Month":"202109"}]}
    // console.log(test, 'test')
    // console.log(Object.keys(test));

    // const chartLabel = Object.keys(test);

    // if (chartLabel.length > 0) {
    //   console.log(test[chartLabel[0]])

    //   const months = test[chartLabel[0]].map(item => item.Month)
    //   console.log(months,' months')

    //   const dataSet :any = []
    //   chartLabel.forEach((item, index) => {
    //     console.log(item, index)  
    //     console.log(test[chartLabel[index]], 'index', chartLabel[index])
    //     const obj = { data: test[chartLabel[index]].map(item => item.AdjustedPenetrationRate), label: chartLabel[index] }
    //     dataSet.push(obj)       
    //   })

    //   console.log(dataSet, 'dataSet')

    // }

  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  get f() { return this.searchForm.controls; }  

  getDivisions(): void {
    this.loadingDivisions = true;      
    this.divisions$ = this.appService
                .getDivisions(
                  this.tokenStorageService.getAccountGUID(), 
                  this.tokenStorageService.getUserGUID()
                )
                .pipe(   
                  map(response => response.map(item => {
                    return {...item, Name: `${item.Code} - ${item.Name}`}
                  })),
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingDivisions=false)
                )

  }
  
  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.dashboardService.getPenetrationRate(
      this.f.pDivisionCode.value,
      this.tokenStorageService.getUserGUID(),
      this.f.pReportingYYYYMM_From.value,
      this.f.pReportingYYYYMM_To.value
    ).subscribe(
      data => {
        if (data.length > 0) {
          

          const groupByData = groupBy(data, (d) => d.Township);
          console.log(groupByData, 'groupByData');


          const chartLabel = Object.keys(groupByData);

          if (chartLabel.length > 0) {            
            const dataSet :any = []
            chartLabel.forEach((item, index) => {
              const obj = { data: groupByData[chartLabel[index]].map(item => item.AdjustedPenetrationRate), label: chartLabel[index] }
              dataSet.push(obj)       
            })
            
            this.barChartLabels = groupByData[chartLabel[0]].map(item => item.Month.substring(0, 4) + "-" + item.Month.substring(4, item.Month.length))
            this.barChartData = dataSet
          }
           
          this.dataPenetrationRate = data;  


          

        } else {
          this.toastr.error("No data.");
        }
        this.btnLoading = false;
        this.rerender()
        console.log('dataPenetrationRate', data);
      },
      err => {
        this.btnLoading = false;
        console.log('dataPenetrationRate', err);
      }
    )
  }

}
