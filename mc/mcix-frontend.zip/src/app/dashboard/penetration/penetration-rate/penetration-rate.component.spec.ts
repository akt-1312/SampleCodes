import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PenetrationRateComponent } from './penetration-rate.component';

describe('PenetrationRateComponent', () => {
  let component: PenetrationRateComponent;
  let fixture: ComponentFixture<PenetrationRateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PenetrationRateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PenetrationRateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
