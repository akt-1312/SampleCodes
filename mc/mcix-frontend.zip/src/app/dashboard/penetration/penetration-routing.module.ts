import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth.guard';
import { PenetrationRateComponent } from './penetration-rate/penetration-rate.component';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/penetration/rate', pathMatch: 'full' },
  { path: 'rate', component:  PenetrationRateComponent, canActivate: [AuthGuard], data: {menuId: '33'} }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PenetrationRoutingModule { }
