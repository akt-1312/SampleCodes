import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from "angular-datatables";
import { NgSelectModule } from '@ng-select/ng-select';
import { ChartsModule } from 'ng2-charts';
import { ShareModule } from 'src/app/shared/module/share/share.module';

import { PenetrationRoutingModule } from './penetration-routing.module';
import { PenetrationRateComponent } from './penetration-rate/penetration-rate.component';


@NgModule({
  declarations: [
    PenetrationRateComponent
  ],
  imports: [
    CommonModule,
    PenetrationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    NgSelectModule,
    ChartsModule,
    ShareModule
  ]
})
export class PenetrationModule { }
