import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuditOverviewComponent } from './audit-overview/audit-overview.component';
import { AuditDetailComponent } from './audit-detail/audit-detail.component';
import { AuthGuard } from 'src/app/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/audit/overview', pathMatch: 'full' },
  { path: 'overview', component:  AuditOverviewComponent, canActivate: [AuthGuard], data: {menuId: '34'} },
  { path: 'detail', component:  AuditDetailComponent, canActivate: [AuthGuard], data: {menuId: '35'} }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuditRoutingModule { }
