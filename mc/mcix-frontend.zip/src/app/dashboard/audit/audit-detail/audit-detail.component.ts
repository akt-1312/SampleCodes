import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ActivatedRoute  } from "@angular/router";
import { ClientService } from 'src/app/shared/service/client.service';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { ToastrService } from 'ngx-toastr';
import { DataTableDirective } from 'angular-datatables';
import { Observable, of, Subject } from 'rxjs';
import { catchError, finalize  } from 'rxjs/operators';

import { IResAppUser } from 'src/app/shared/model/response/IResAppUser';
import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { IResAuditDetailHeader } from 'src/app/shared/model/response/IResAuditDetailHeader';
import { IResAuditDetailBody } from 'src/app/shared/model/response/IResAuditDetailBody';

@Component({
  selector: 'app-audit-detail',
  templateUrl: './audit-detail.component.html',
  styleUrls: ['./audit-detail.component.scss']
})
export class AuditDetailComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  loadingAppUsers = false;
  appUsers$: Observable<IResAppUser[]>;

  offHours = ''
  hours: IResCodeName[] = []
  
  errorMsg: string;

  
  auditHeader: IResAuditDetailHeader = <IResAuditDetailHeader>{};
  auditBody: IResAuditDetailBody[] = []

  params: any = { UserGUID: '', startDate: '', endDate: '', offHours: '' }

  searchForm: FormGroup = new FormGroup({
    userGuid: new FormControl(),
    dateRange: new FormControl(),
    offHours: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;

  bsRangeValue: Date[] = [];
  maxDate: Date = new Date();
  startDateStr: Date = new Date();
  endDateStr: Date = new Date();

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private tokenStorageService: TokenStorageService,
    private clientService: ClientService,
    private toastr: ToastrService
  ) {
    this.startDateStr.setDate(this.startDateStr.getDate() - 7)
    this.bsRangeValue = [this.startDateStr, this.endDateStr];
    this.maxDate = new Date();
  }

  ngOnInit(): void {

    this.hours = [
      { Code: 'NO', Name: 'Working hours' },
      { Code: 'YES', Name: 'Off hours' },
      { Code: 'ALL', Name: 'All' }
    ];

    this.searchForm = this.formBuilder.group({
      userGuid: [null, [Validators.required]],
      dateRange: [new Date(), [Validators.required]],
      offHours: [null, [Validators.required]],
    });

    this.dtOptions = {     
      responsive: true
    }; 

    this.getQueryParams()
    this.getAppUsers();
    
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }


  get f() { return this.searchForm.controls; }  

  getQueryParams() {
    this.route.queryParamMap
    .subscribe((params) => {
      this.params = { UserGUID: params.get('UserGUID'), startDate: params.get('startDate'), endDate: params.get('endDate'), offHours: params.get('offHours') }
      
      if (this.params.startDate) {
        this.bsRangeValue = [new Date(this.params.startDate), new Date(this.params.endDate)];
      }

      this.searchForm.patchValue({
        userGuid: this.params.UserGUID,
        offHours: this.params.offHours
      })

      this.onSubmit();
    })
  } 

  getAppUsers(): void {
    this.loadingAppUsers = true;      
    this.appUsers$ = this.clientService
                .getAppUsers(this.tokenStorageService.getAccountGUID())
                .pipe(       
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingAppUsers=false)
                );
  }

  onSubmit() {
    

    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.clientService.getSearchAuditResults(
      this.f.userGuid.value,
      new Date(this.f.dateRange.value[0]).toLocaleDateString('en-GB'),
      new Date(this.f.dateRange.value[1]).toLocaleDateString('en-GB'),
      this.f.offHours.value
    ).subscribe(
      data => {
        
        this.auditHeader = data[0];
        this.auditBody = data[1];
        
        if(!this.auditHeader.MFIName) {
          this.toastr.error("No matching results found!");
        }
        
        this.btnLoading = false;

        this.rerender()
      }, 
      err => {
        console.log(err, 'error');
        this.btnLoading = false;
      }
    )
  }

  

}
