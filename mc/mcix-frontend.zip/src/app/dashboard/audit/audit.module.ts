import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDatepickerModule, BsDatepickerConfig  } from 'ngx-bootstrap/datepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from "angular-datatables";
import { NgSelectModule } from '@ng-select/ng-select';
import { ShareModule } from 'src/app/shared/module/share/share.module';
import { TooltipModule } from 'ngx-bootstrap/tooltip';

import { AuditRoutingModule } from './audit-routing.module';
import { AuditOverviewComponent } from './audit-overview/audit-overview.component';
import { AuditDetailComponent } from './audit-detail/audit-detail.component';


@NgModule({
  declarations: [
    AuditOverviewComponent,
    AuditDetailComponent
  ],
  imports: [
    CommonModule,    
    AuditRoutingModule,
    DataTablesModule,
    FormsModule,
    ReactiveFormsModule,
    ShareModule,
    NgSelectModule,
    TooltipModule.forRoot(),
    BsDatepickerModule.forRoot(),
  ],
  providers: [BsDatepickerConfig],
})
export class AuditModule { }
