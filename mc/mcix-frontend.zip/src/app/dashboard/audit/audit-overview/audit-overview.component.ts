import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { Observable, of, Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { ClientService } from 'src/app/shared/service/client.service';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';

import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { IResAuditOverview } from 'src/app/shared/model/response/IResAuditOverview';
import { exportToCsv } from 'src/app/shared/helper/exportCsv';

@Component({
  selector: 'app-audit-overview',
  templateUrl: './audit-overview.component.html',
  styleUrls: ['./audit-overview.component.scss']
})
export class AuditOverviewComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  auditOverviewData: IResAuditOverview[] = []

  offHours = ''
  hours: IResCodeName[] = []
  
  searchForm: FormGroup = new FormGroup({
    dateRange: new FormControl(),
    offHours: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;
  error = '';
  bsRangeValue: Date[] = [];
  maxDate: Date = new Date();
  startDateStr: Date = new Date();
  endDateStr: Date = new Date();

  
  constructor(
    private formBuilder: FormBuilder,
    private tokenStorageService: TokenStorageService,
    private clientService: ClientService
  ) {
    this.startDateStr.setDate(this.startDateStr.getDate() - 7)
    this.bsRangeValue = [this.startDateStr, this.endDateStr];
    this.maxDate = new Date();
  }

  ngOnInit(): void {      

    this.dtOptions = {      
      responsive: true      
    }; 

    this.hours = [
        { Code: 'NO', Name: 'Working hours' },
        { Code: 'YES', Name: 'Off hours' },
        { Code: 'ALL', Name: 'All' }
    ];

    this.searchForm = this.formBuilder.group({
      dateRange: [new Date(), [Validators.required]],
      offHours: [null, [Validators.required]],
    });
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  get f() { return this.searchForm.controls; }  

  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

   

    this.clientService.getSearchAuditResultsForAllUsers(
      this.tokenStorageService.getAccountGUID(),
      new Date(this.f.dateRange.value[0]).toLocaleDateString('en-GB'),
      new Date(this.f.dateRange.value[1]).toLocaleDateString('en-GB'),
      this.f.offHours.value
    ).subscribe(
      data => {
        
        this.auditOverviewData = data;
        console.log(this.auditOverviewData);
        this.btnLoading = false;
        this.rerender()
      }, 
      err => {
        console.log(err, 'error');
        this.btnLoading = false;
      }
    )
  }

  downloadCsv() {
    const data = [["User Id", "No Of NRC searched"]];
    this.auditOverviewData.forEach(item => {
      const arr = [item['UserName'], item['NoOfNRCSearched']]
      data.push(arr);
    })
    exportToCsv('search audit overview.csv', data)
  }

}
