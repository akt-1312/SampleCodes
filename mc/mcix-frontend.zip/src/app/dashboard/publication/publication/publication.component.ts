import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/shared/service/dashboard.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-publication',
  templateUrl: './publication.component.html',
  styleUrls: ['./publication.component.scss']
})
export class PublicationComponent implements OnInit {

  dtOptions: DataTables.Settings = {};

  fileList: any = [];
  filePath = ''
  

  loading = false;
  errorMsg = '';

  pdfSrc: any = '';

  originalSize = true;  
  showAll = true;
  fitToPage = false;   
  zoom = 1.0;  
  autoresize = true;
  showBoder = false;

  containerName = 'publication'

  constructor(
    private dashboardService: DashboardService,
    private toastr: ToastrService
  ) { }
  
  ngOnInit(): void {  

    this.dtOptions = {
      columns: [
        { "searchable": false, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": false, orderable: false }
      ],
      responsive: true      
    }; 

    this.getPublicationListBlobs()

  }

  getPublicationListBlobs(): void {
    this.loading = true; 
    this.dashboardService.getPublicationListBlobs().subscribe(data => {
      console.log(data, 'data')
      this.fileList = data;
      this.loading = false; 
    }, err => {
      this.errorMsg = err
      this.loading = false;
    })
  }
  
  // loadPdf(file: string) {
  //   this.loading = true; 
  //   const xhr = new XMLHttpRequest();
  //   xhr.open('GET', file, true);
  //   xhr.responseType = 'blob';

  //   xhr.onload = (e: any) => {
  //     console.log(xhr, 'xhr');
  //     if (xhr.status === 200) {
  //       const blob = new Blob([xhr.response], { type: 'application/pdf' });
  //       this.pdfSrc = URL.createObjectURL(blob);
  //       console.log(this.pdfSrc, 'pdfSrc')
  //       this.loading = false;
  //     }
  //   };

    

  //   xhr.onerror = (e: any) => {
  //     this.loading = false;
  //     this.toastr.error("Something Went Wrong!")
  //   }

  //   xhr.send();
    
  // }

  loadPdf(fileName: string) {
    this.loading = true;
    this.dashboardService.getBase64BlobPdfData(fileName, this.containerName).subscribe(data => {     
      this.pdfSrc = data
      this.loading = false;
    },
    err => {
      this.loading = false;
      this.errorMsg = err;
      this.toastr.error("Something Went Wrong!")
    })
  }

}
