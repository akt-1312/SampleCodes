import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth.guard';
import { PublicationComponent } from './publication/publication.component';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/publication/publication', pathMatch: 'full' },
  { path: 'publication', component:  PublicationComponent, canActivate: [AuthGuard], data: {menuId: '37'} }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PublicationRoutingModule { }
