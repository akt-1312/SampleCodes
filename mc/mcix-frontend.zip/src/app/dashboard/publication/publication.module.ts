import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DataTablesModule } from "angular-datatables";
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ShareModule } from 'src/app/shared/module/share/share.module';

import { PublicationRoutingModule } from './publication-routing.module';
import { PublicationComponent } from './publication/publication.component';


@NgModule({
  declarations: [
    PublicationComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    PublicationRoutingModule,
    DataTablesModule,
    PdfViewerModule,
    ShareModule,
    TooltipModule.forRoot()
  ]
})
export class PublicationModule { }
