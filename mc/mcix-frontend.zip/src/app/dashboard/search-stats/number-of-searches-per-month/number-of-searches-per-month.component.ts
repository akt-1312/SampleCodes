import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { DashboardService } from 'src/app/shared/service/dashboard.service';

@Component({
  selector: 'app-number-of-searches-per-month',
  templateUrl: './number-of-searches-per-month.component.html',
  styleUrls: ['./number-of-searches-per-month.component.scss']
})
export class NumberOfSearchesPerMonthComponent implements OnInit {
  
  
  loading = false;
  errorMsg: string;

  inquiryByAccount = []

  barChartOptions: ChartOptions = {responsive: true, scales: {yAxes: [{ticks: {beginAtZero: true}}]}};
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [];  
  barChartColors: Color[] = [
    { borderColor: '#4e73df',  backgroundColor: '#4e73df' },
    { borderColor: '#1cc88a',  backgroundColor: '#1cc88a' }
  ]

  constructor(
    private tokenStorageService: TokenStorageService,
    private dashboardService: DashboardService
  ) { }

  ngOnInit(): void {
    this.getInquiryByAccount()
  }

  getInquiryByAccount(): void {
    this.loading = true;
    this.dashboardService.getInquiryByAccount(this.tokenStorageService.getAccountGUID()).subscribe(
      data => {
        console.log(data, 'data')
        if (data.length>0) {
          

          this.barChartLabels = data.map(item => item.InquiryYYYYMM)
          const dataSet = data.map(item => item.Num)
          this.barChartData = [{ data: dataSet, label: "Number of Searches" }] 
          this.inquiryByAccount = data      


        }
        this.loading = false;
        console.log('getInquiryByAccount', data);
      },
      err => {
        this.loading = false;
        console.log('getInquiryByAccount', err);
      }
    )
  }

}
