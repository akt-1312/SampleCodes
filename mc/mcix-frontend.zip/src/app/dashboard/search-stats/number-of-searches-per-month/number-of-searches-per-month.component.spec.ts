import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberOfSearchesPerMonthComponent } from './number-of-searches-per-month.component';

describe('NumberOfSearchesPerMonthComponent', () => {
  let component: NumberOfSearchesPerMonthComponent;
  let fixture: ComponentFixture<NumberOfSearchesPerMonthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NumberOfSearchesPerMonthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberOfSearchesPerMonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
