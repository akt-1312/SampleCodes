import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { NgSelectModule } from '@ng-select/ng-select';
import { ShareModule } from 'src/app/shared/module/share/share.module';

import { SearchStatsRoutingModule } from './search-stats-routing.module';
import { NumberOfSearchesPerUserComponent } from './number-of-searches-per-user/number-of-searches-per-user.component';
import { NumberOfSearchesPerMonthComponent } from './number-of-searches-per-month/number-of-searches-per-month.component';


@NgModule({
  declarations: [
    NumberOfSearchesPerUserComponent,
    NumberOfSearchesPerMonthComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SearchStatsRoutingModule,
    NgSelectModule,
    ChartsModule,
    ShareModule
  ]
})
export class SearchStatsModule { }
