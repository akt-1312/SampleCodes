import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NumberOfSearchesPerUserComponent } from './number-of-searches-per-user/number-of-searches-per-user.component';
import { NumberOfSearchesPerMonthComponent } from './number-of-searches-per-month/number-of-searches-per-month.component';
import { AuthGuard } from 'src/app/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard/search-stats/user', pathMatch: 'full' },
  { path: 'user', component:  NumberOfSearchesPerUserComponent, canActivate: [AuthGuard], data: {menuId: '31'} },
  { path: 'month', component:  NumberOfSearchesPerMonthComponent, canActivate: [AuthGuard], data: {menuId: '32'} }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SearchStatsRoutingModule { }
