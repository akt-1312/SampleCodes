import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberOfSearchesPerUserComponent } from './number-of-searches-per-user.component';

describe('NumberOfSearchesPerUserComponent', () => {
  let component: NumberOfSearchesPerUserComponent;
  let fixture: ComponentFixture<NumberOfSearchesPerUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NumberOfSearchesPerUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberOfSearchesPerUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
