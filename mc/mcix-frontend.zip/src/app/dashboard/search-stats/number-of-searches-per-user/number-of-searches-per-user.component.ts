import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';
import { AppService } from 'src/app/shared/service/app.service';
import { DashboardService } from 'src/app/shared/service/dashboard.service';

import { IResCodeName } from 'src/app/shared/model/response/IResCodeName';
import { Observable, of } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';
import { getLastMonths } from 'src/app/shared/helper/months';

@Component({
  selector: 'app-number-of-searches-per-user',
  templateUrl: './number-of-searches-per-user.component.html',
  styleUrls: ['./number-of-searches-per-user.component.scss']
})
export class NumberOfSearchesPerUserComponent implements OnInit {

  loadingDivisions = false;
  divisions$: Observable<IResCodeName[]>;

  loadingTownships = false;
  townships$: Observable<IResCodeName[]>;

  
  months: IResCodeName[];

  errorMsg: string;  

  searchForm: FormGroup = new FormGroup({
    pDivisionCode: new FormControl(),
    pTownshipCode: new FormControl(),
    pReportingYYYYMM: new FormControl()
  });

  loading = false;
  btnLoading = false;
  submitted = false;

  getSearchRecordByUser = []

  barChartOptions: ChartOptions = {responsive: true, scales: {yAxes: [{ticks: {beginAtZero: true}}]}};
  barChartLabels: Label[] = [];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataSets[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private tokenStorageService: TokenStorageService,
    private dashboardService: DashboardService,
  ) { }

  ngOnInit(): void {

    this.searchForm = this.formBuilder.group({
      pDivisionCode: [null, [Validators.required]],
      pTownshipCode: [null, [Validators.required]],
      pReportingYYYYMM: [null, [Validators.required]]
    });

    this.getDivisions()

    this.months = getLastMonths(6);

  }

  get f() { return this.searchForm.controls; } 

  getDivisions(): void {
    this.loadingDivisions = true;      
    this.divisions$ = this.appService
                .getDivisions(
                  this.tokenStorageService.getAccountGUID(), 
                  this.tokenStorageService.getUserGUID()
                )
                .pipe(   
                  map(response => response.map(item => {
                    return {...item, Name: `${item.Code} - ${item.Name}`}
                  })),
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingDivisions=false)
                )

  }

  onChangeDivisions(): void {
    console.log('change', this.f.pDivisionCode.value)
    this.getTownships();
  }

  getTownships(): void {
    this.loadingTownships = true;
    this.townships$ = this.appService
                        .getTownships(
                          this.f.pDivisionCode.value,
                          this.tokenStorageService.getAccountGUID(), 
                          this.tokenStorageService.getUserGUID()
                        )
                        .pipe(
                          map(response => response.map(item => {
                            return {...item, Name: `${item.Code} - ${item.Name}`}
                          })),
                          catchError(error => {
                            this.errorMsg = error.message;
                            return of([]);
                          }),
                          finalize(()=>this.loadingTownships=false)
                        )
    
  }

  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    this.dashboardService.getSearchRecordByUser(
      this.f.pDivisionCode.value,
      this.f.pTownshipCode.value,
      this.f.pReportingYYYYMM.value,
      this.tokenStorageService.getUserGUID()
    ).subscribe(
      data => {
        if (data.length > 0) {       
          this.barChartLabels = data.map(item => item.Email)
          const dataSet = data.map(item => item.NoOfSearch)
          this.barChartData = [{ data: dataSet, label: "Number of Searches" }] 
          this.getSearchRecordByUser = data      
        }        
        this.btnLoading = false;        
      },
      err => {
        this.btnLoading = false;
      }
    )
  }

}
