import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { DataTablesModule } from "angular-datatables";
import { ShareModule } from 'src/app/shared/module/share/share.module';
import { TooltipModule } from 'ngx-bootstrap/tooltip';

import { CompanyProfileRoutingModule } from './company-profile-routing.module';
import { CompanyStatsComponent } from './company-stats/company-stats.component';
import { CompanyStatsDetailComponent } from './company-stats-detail/company-stats-detail.component';


@NgModule({
  declarations: [
    CompanyStatsComponent,
    CompanyStatsDetailComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    ShareModule,
    CompanyProfileRoutingModule,
    NgSelectModule,
    TooltipModule.forRoot(),
  ]
})
export class CompanyProfileModule { }
