import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { CompanyStatsComponent } from './company-stats/company-stats.component';
import { CompanyStatsDetailComponent } from './company-stats-detail/company-stats-detail.component';

const routes: Routes = [
  { path: '', redirectTo: '/company-profile/stats', pathMatch: 'full' },
  { path: 'stats', component:  CompanyStatsComponent, canActivate: [AuthGuard], data: {menuId: '41'} },
  { path: 'stats-detail/:pLGUID/:pReportingDate/:pShowOnlyBadFlag', component:  CompanyStatsDetailComponent, canActivate: [AuthGuard], data: {menuId: '41'} }  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyProfileRoutingModule { }
