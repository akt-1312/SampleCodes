import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyStatsDetailComponent } from './company-stats-detail.component';

describe('CompanyStatsDetailComponent', () => {
  let component: CompanyStatsDetailComponent;
  let fixture: ComponentFixture<CompanyStatsDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanyStatsDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyStatsDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
