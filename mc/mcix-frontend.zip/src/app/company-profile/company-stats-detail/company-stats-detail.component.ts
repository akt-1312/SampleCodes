import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { CompanyProfileService } from 'src/app/shared/service/company-profile.service';

import { IResCompanyStatsDetail } from 'src/app/shared/model/response/IResCompanyStatsDetail';

@Component({
  selector: 'app-company-stats-detail',
  templateUrl: './company-stats-detail.component.html',
  styleUrls: ['./company-stats-detail.component.scss']
})
export class CompanyStatsDetailComponent implements OnInit {

  loading = false;
  errorMsg = '';  

  dtOptions: DataTables.Settings = {};

  profileDetailData: IResCompanyStatsDetail[] = []

  constructor(
    private route: ActivatedRoute,
    private companyProfileService: CompanyProfileService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {

    this.dtOptions = {
      responsive: true
    };

    this.getCompanyProfileDetails()
  }

  getCompanyProfileDetails(): void {
    this.loading = true;
    this.route.params.subscribe(params => {    
      const pLGUID = params.pLGUID;
      const pReportingDate =params.pReportingDate.replace('-', '');
      const pShowOnlyBadFlag = params.pShowOnlyBadFlag;

      this.companyProfileService.getCompanyProfileDetails(
        pLGUID,
        pReportingDate,
        pShowOnlyBadFlag
      ).subscribe(data => {
        this.profileDetailData = data;
        this.loading = false;
      },
      err => {
        this.loading = false;
        this.errorMsg = err;
        this.toastr.error("Error.")
      })
    })
  }

}
