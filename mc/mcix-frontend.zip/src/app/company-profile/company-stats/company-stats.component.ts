
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { DataTableDirective } from 'angular-datatables';
import { Observable, of, Subject } from 'rxjs';
import { catchError, finalize, map  } from 'rxjs/operators';

import { AppService } from 'src/app/shared/service/app.service';
import { ClientService } from 'src/app/shared/service/client.service';
import { CompanyProfileService } from 'src/app/shared/service/company-profile.service';
import { TokenStorageService } from 'src/app/shared/service/token-storage.service';


import { IResCompanyProfile } from 'src/app/shared/model/response/IResCompanyProfile';
import { IResMFI } from 'src/app/shared/model/response/IResMFI';
import { IReqGetCompanyProfile } from 'src/app/shared/model/request/IReqGetCompanyProfile';
import { exportToCsv } from 'src/app/shared/helper/exportCsv';
import { userRole } from 'src/app/shared/config/user-role';

@Component({
  selector: 'app-company-stats',
  templateUrl: './company-stats.component.html',
  styleUrls: ['./company-stats.component.scss']
})
export class CompanyStatsComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  
  isDashboardUserRole = false;

  
  mfiData: IResMFI[] = [];

  loadingMfis = false;
  mfis$: Observable<[]>;

  loadingReportingDates = false;
  reportingDates$: Observable<[]>;


  companyProfileData: IResCompanyProfile[] = [];

  searchForm: FormGroup = new FormGroup({
    pReportingYYYYMM_From: new FormControl(),
    pReportingYYYYMM_To: new FormControl(),
    pMFIAccountId: new FormControl(),
  });

  loading = false;
  btnLoading = false;
  submitted = false;
  errorMsg = '';

  fileName = 'Company Profile.csv';

  reqCompanyProfile: IReqGetCompanyProfile


  constructor(
    private formBuilder: FormBuilder,
    private appService: AppService,
    private tokenStorageService: TokenStorageService,
    private clientService: ClientService,
    private companyProfileService: CompanyProfileService
  ) { }

  ngOnInit(): void {
    this.checkedDashboardUserRole()

    this.searchForm = this.formBuilder.group({
      pMFIAccountId: [null, [Validators.required]],
      pReportingYYYYMM_From: [null, [Validators.required, Validators.min(1)]],
      pReportingYYYYMM_To: [null, [Validators.required, Validators.min(1)]]
    });

    this.dtOptions = {
      columns: [
        { "searchable": false, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true },
        { "searchable": true, orderable: true }
      ],
      responsive: true
    }; 

    this.getReportingDateForCompanyProfile();

    if (this.isDashboardUserRole) {
      this.getAllMFIs();
    } else {
      this.searchForm.controls.pMFIAccountId.disable();
      this.getSingleMFI();
    }
    
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  get f() { return this.searchForm.controls; }  
  
  checkedDashboardUserRole() {
    const role = this.tokenStorageService.getUserRole();
    if ((role === userRole.dashboardAdmin) || (role === userRole.dashboardSuperuser)) {
      this.isDashboardUserRole = true
    } else {
      this.isDashboardUserRole = false
    }
  }

  getSingleMFI(): void {
    this.loading = true;
    this.clientService.getAllMFIs(this.tokenStorageService.getUserGUID()).subscribe(
      data => {
        this.mfiData = data;
        this.loading = false;
        console.log('getAllMFIs', data);
      },
      err => {
        this.loading = false;
        this.errorMsg = err;
        console.log('getAllMFIs', err);
      }
    )
  }

  getAllMFIs(): void {
    this.loadingMfis = true;      
    this.mfis$ = this.clientService
                .getAllMFIs(this.tokenStorageService.getUserGUID())
                .pipe(
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingMfis=false)
                );
  }


  getReportingDateForCompanyProfile() {
    this.loadingReportingDates = true;      
    this.reportingDates$ = this.appService.getReportingDateForCompanyProfile()
                .pipe(          
                  catchError(error => {
                    this.errorMsg = error.message;
                    return of([]);
                  }),
                  finalize(()=>this.loadingReportingDates=false)
                );
  }
  

  onCheckedMfi() {
    if (this.searchForm.controls.pMFIAccountId.disabled) {
      this.searchForm.controls.pMFIAccountId.enable();
    } else {
        this.searchForm.controls.pMFIAccountId.disable();
    }

    this.searchForm.patchValue({pMFIAccountId: null})
  }

  getGuidArrForDashboardUserRole(): string {
    let pLGUIDstringarray;
    if (this.searchForm.controls.pMFIAccountId.disabled) {
      pLGUIDstringarray = { "pLGUID": ["all"] }
    } else {
      pLGUIDstringarray = { "pLGUID": this.f.pMFIAccountId.value }
    }
    return pLGUIDstringarray;
  }

  getGuidArrForOtherUserRole() {    
    const guid = this.mfiData.length ? this.mfiData[0].LGUID : "";
    return  { "pLGUID": [guid] }
  }

  onSubmit() {
    this.submitted = true;

    if (this.searchForm.invalid) {
      return;
    }

    this.btnLoading = true;

    const pLGUIDstringarray = this.isDashboardUserRole ? this.getGuidArrForDashboardUserRole() : this.getGuidArrForOtherUserRole()
   

    this.reqCompanyProfile = {
      pLGUIDstringarray: JSON.stringify(pLGUIDstringarray),
      pReportingYYYYMM_From: this.f.pReportingYYYYMM_From.value,
      pReportingYYYYMM_To: this.f.pReportingYYYYMM_To.value
    }

    this.companyProfileService.getCompanyProfile(
      this.reqCompanyProfile
    ).subscribe(
      data => {
        if (data.length) {
          this.companyProfileData = data;         
          this.btnLoading = false;
        
          console.log('getCompanyProfile', data);
          this.rerender()
        } 
        
      },
      err => {
        this.btnLoading = false;
        console.log('getCompanyProfile', err);
      }
    )
  }

  downloadCsv() {
    const data = [[
      "Month", 
      "MFI", 
      "Active borrowers(stated)", 
      "Active borrowers(uploaded)", 
      "Active townships(stated)", 
      "Active townships(uploaded)", 
      "Writeoff borrowers(stated)", 
      "Total principal writeoffs(stated)", 
      "Percentage"]];
    this.companyProfileData.forEach(item => {
      const arr: any = [
        item['Month'], 
        item['MFI'], 
        item['NoOfActiveBorrowersStated'], 
        item['NoOfActiveBorrowerUploaded'], 
        item['NoOfActiveTownshipsStated'], 
        item['NoOfActiveTownshipUploaded'], 
        item['NoOfWriteOffBorrowersStated'], 
        item['TotalPrincipalWriteOffStated'], 
        item['Percentage']]
      data.push(arr);
    })
    exportToCsv(this.fileName, data)
  }

}
