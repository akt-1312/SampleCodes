import { Component } from '@angular/core';
import { AuthService } from './shared/service/auth.service';
import { TranslateService } from '@ngx-translate/core';
import { TokenStorageService } from './shared/service/token-storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {  

  isLoggedIn = false;

  constructor(
    private authService: AuthService,
    private translate: TranslateService,
    private tokenStorageService: TokenStorageService
  ) { 
    this.authService.token.subscribe(x => this.isLoggedIn = x.access_token ? true : false)

    translate.addLangs(['en', 'my']);
    translate.setDefaultLang('en');
    
    const lang = this.tokenStorageService.getLang(); 
    translate.use(lang ? lang : 'en');
   
  } 

}
